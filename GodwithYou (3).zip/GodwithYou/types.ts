
export interface User {
  id: string;
  name: string;
  email: string;
  password?: string; // For simulated auth
  avatar?: string;
  bio?: string;
  theme: 'dark' | 'light';
  apiKey?: string;
  digitalTwin?: {
    lastUpdate: number;
    personalitySummary: string;
    coreValues: string[];
    currentFocus: string;
    evolutionLevel: number; // 1-100
    archetype?: string; 
  };
  stats: {
    currentStreak: number;
    longestStreak: number;
    lastTaskDate: string; // YYYY-MM-DD
    xp: number;
    energyScore: number; // 0-100
  };
}

export type BrainType = 'ASTRA' | 'LUMA' | 'FLOW' | 'CORE';

export interface TimelineEvent {
  id: string;
  title: string;
  date: string;
  description: string;
  type: 'past' | 'prediction' | 'goal';
  impact: 'positive' | 'negative' | 'neutral';
  category: string;
}

export interface DecisionLog {
  id: string;
  query: string;
  options: string[];
  analysis: string;
  recommendation?: string;
  option_details?: {
    option: string;
    probability: number;
    emotional_impact: string;
    energy_cost: string;
    time_cost: string;
    long_term_consequences: string;
    outcome: string;
  }[];
  timestamp: number;
  tags: string[];
}

export interface Note {
  id: string;
  title: string;
  content: string;
  tags: string[];
  priority: 'low' | 'medium' | 'high';
  updatedAt: number;
  aiSummary?: string;
}

export interface EmotionLog {
  id: string;
  mood: number; // 1-10
  energy: number; // 1-100
  labels: string[]; 
  note: string;
  timestamp: number;
  aiAnalysis?: string;
  recoveryMode?: string; // Suggested recovery action
}

export interface Project {
  id: string;
  name: string;
  description: string;
  status: 'planning' | 'active' | 'completed';
  progress: number;
  tasks: Task[];
}

export interface Task {
  id: string;
  projectId?: string;
  title: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  dueDate?: string;
  timeWarpType?: 'microburst' | 'deep-pod' | 'cycle'; // TimeWarp Automation
  durationMinutes?: number;
}

export interface KnowledgeItem {
  id: string;
  query: string;
  summary: string;
  explanation: string;
  sources: string[];
  workflow?: string[]; // Generated steps
  timestamp: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  brain?: BrainType;
}

// --- NEW FEATURES ---

export interface Strike {
  id: string;
  creatorId: string; // Anonymous ID
  title: string;
  description: string;
  type: 'focus' | 'fitness' | 'learning' | 'custom';
  durationDays: number;
  dailyGoal: string;
  difficulty: 'easy' | 'medium' | 'hard' | 'god-mode';
  participantsCount: number;
  tags: string[];
  createdAt: number;
}

export interface StrikeParticipation {
  id: string;
  strikeId: string;
  userId: string;
  startDate: string;
  currentDay: number;
  completedDates: string[]; // YYYY-MM-DD
  active: boolean;
}

export enum AppRoute {
  DASHBOARD = '/',
  TIMELINE = '/timeline',
  DECISIONS = '/decisions',
  WORKSPACE = '/workspace',
  SENSE = '/sense',
  EMOTIONS = '/emotions',
  KNOWLEDGE = '/knowledge',
  CHAT = '/chat',
  PROJECTS = '/projects',
  HISTORY = '/history',
  PROFILE = '/profile',
  HELP = '/help',
  FEEDBACK = '/feedback',
  LOGIN = '/login',
  STRIKES = '/strikes'
}