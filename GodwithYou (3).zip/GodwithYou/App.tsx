import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation, Link } from 'react-router-dom';
import { 
  LayoutDashboard, GitFork, BrainCircuit, Notebook, Sparkles, 
  HeartPulse, Search, MessageSquare, Briefcase, History as HistoryIcon, 
  UserCircle, HelpCircle, Mail, Menu, X, LogOut, Bot, Flame, BatteryCharging
} from 'lucide-react';

import * as DB from './services/db';
import * as AI from './services/ai';
import { AppRoute, User } from './types';
import RestOverlay from './components/RestOverlay';
import { NeuroSyncProvider } from './components/NeuroSyncProvider';

// Pages
import Dashboard from './pages/Dashboard';
import Timeline from './pages/Timeline';
import Decisions from './pages/Decisions';
import Workspace from './pages/Workspace';
import Sense from './pages/Sense';
import Emotions from './pages/Emotions';
import Knowledge from './pages/Knowledge';
import Chat from './pages/Chat';
import Projects from './pages/Projects';
import ProjectDetails from './pages/ProjectDetails';
import HistoryPage from './pages/History';
import Profile from './pages/Profile';
import Help from './pages/Help';
import Feedback from './pages/Feedback';
import Auth from './pages/Auth';
import Strikes from './pages/Strikes';
import StrikeDetails from './pages/StrikeDetails';

// Context
interface AppContextType {
  user: User | null;
  setUser: (u: User | null) => void;
  isLoading: boolean;
  restMode: boolean;
  setRestMode: (v: boolean) => void;
}
export const AppContext = createContext<AppContextType>({ 
    user: null, 
    setUser: () => {}, 
    isLoading: true,
    restMode: false,
    setRestMode: () => {}
});

// Custom Star Logo Component
const StarLogo = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 relative z-10">
    <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L12 3Z"/>
  </svg>
);

// Whisper AI Sidekick Component
const WhisperAI = () => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [brain, setBrain] = useState<string>('CORE');

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setResponse('');
    
    try {
      const res = await AI.getWhisperResponse(query);
      setResponse(res.text);
      setBrain(res.brain);
    } catch (err) {
      setResponse("Signal lost.");
    }
    setLoading(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {open && (
        <div className="mb-4 w-80 glass-panel p-4 rounded-2xl animate-slide-up border border-primary/20 shadow-[0_0_50px_rgba(139,92,246,0.2)] bg-black/80">
          <div className="flex items-center gap-2 mb-3 border-b border-white/5 pb-2">
            <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded ${
              brain === 'LUMA' ? 'bg-pink-500/20 text-pink-400' : 
              brain === 'ASTRA' ? 'bg-cyan-500/20 text-cyan-400' :
              brain === 'FLOW' ? 'bg-amber-500/20 text-amber-400' : 'bg-violet-500/20 text-violet-400'
            }`}>
              {brain} AI Active
            </span>
          </div>
          
          <div className="h-40 overflow-y-auto custom-scrollbar mb-3 text-sm font-light text-slate-200">
             {loading ? <div className="flex gap-2 items-center text-slate-500"><Sparkles className="animate-spin" size={14}/> Computing...</div> : 
             response ? response : <span className="text-slate-500 italic">"I am listening. How can I assist your flow?"</span>}
          </div>

          <form onSubmit={handleAsk} className="relative">
            <input 
              className="w-full bg-black/40 border border-white/10 rounded-xl py-2 pl-3 pr-10 text-sm focus:border-primary focus:outline-none text-white"
              placeholder="Ask Whisper..."
              value={query}
              onChange={e => setQuery(e.target.value)}
            />
            <button type="submit" className="absolute right-2 top-2 text-primary hover:text-white"><Bot size={16}/></button>
          </form>
        </div>
      )}
      <button 
        onClick={() => setOpen(!open)}
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-110 ${open ? 'bg-primary text-white' : 'glass-panel text-primary border-primary/50'}`}
      >
        <Sparkles size={24} className={loading ? 'animate-spin' : ''} />
      </button>
    </div>
  );
};

// Layout Components
interface SidebarItemProps {
  to: string;
  icon: any;
  label: string;
  active: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ to, icon: Icon, label, active }) => (
  <Link 
    to={to} 
    className={`
      flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden group
      ${active 
        ? 'bg-gradient-to-r from-primary/20 to-secondary/10 text-white border-l-2 border-primary shadow-[0_0_15px_rgba(139,92,246,0.3)]' 
        : 'text-slate-400 hover:bg-white/5 hover:text-white'
      }
    `}
  >
    {active && <div className="absolute inset-0 bg-primary/10 blur-xl"></div>}
    <Icon size={20} className={`relative z-10 transition-transform group-hover:scale-110 ${active ? 'text-primary' : ''}`} />
    <span className="font-medium text-sm relative z-10 font-sans tracking-wide">{label}</span>
  </Link>
);

const Sidebar = ({ mobileOpen, setMobileOpen }: { mobileOpen: boolean, setMobileOpen: (v: boolean) => void }) => {
  const location = useLocation();
  const { user, setUser, setRestMode } = useContext(AppContext);

  const handleLogout = () => {
    DB.logout();
    setUser(null);
  };

  const navs = [
    { to: AppRoute.DASHBOARD, icon: LayoutDashboard, label: 'FlowState' },
    { to: AppRoute.TIMELINE, icon: GitFork, label: 'Timeline' },
    { to: AppRoute.DECISIONS, icon: BrainCircuit, label: 'Quantum Matrix' },
    { to: AppRoute.EMOTIONS, icon: HeartPulse, label: 'LifeSync (Luma)' },
    { to: AppRoute.KNOWLEDGE, icon: Search, label: 'QueryNet (Astra)' },
    { to: AppRoute.STRIKES, icon: Flame, label: 'Strike Protocol' },
    { to: AppRoute.SENSE, icon: Sparkles, label: 'Sense Mode' },
    { to: AppRoute.WORKSPACE, icon: Notebook, label: 'Neural Workspace' },
    { to: AppRoute.CHAT, icon: MessageSquare, label: 'Companion' },
    { to: AppRoute.PROJECTS, icon: Briefcase, label: 'Missions' },
    { to: AppRoute.HISTORY, icon: HistoryIcon, label: 'Chronicles' },
  ];

  const bottoms = [
    { to: AppRoute.PROFILE, icon: UserCircle, label: 'Profile' },
    { to: AppRoute.HELP, icon: HelpCircle, label: 'Knowledge Base' },
    { to: AppRoute.FEEDBACK, icon: Mail, label: 'Feedback' },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {mobileOpen && <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden" onClick={() => setMobileOpen(false)} />}
      
      {/* Sidebar */}
      <aside className={`fixed top-4 bottom-4 left-4 w-64 glass-panel rounded-2xl z-50 transform transition-transform duration-500 lg:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-[110%]'}`}>
        <div className="p-6 flex items-center justify-between border-b border-white/5 gap-2">
          <div className="flex items-center gap-3 overflow-hidden">
             <div className="relative w-10 h-10 flex items-center justify-center bg-black/40 border-2 border-primary/50 rounded-lg shadow-[0_0_20px_rgba(139,92,246,0.3)] overflow-hidden shrink-0">
                 <div className="absolute inset-0 bg-primary/20 blur-md"></div>
                 <StarLogo />
             </div>
             <h1 className="text-lg font-bold text-white tracking-wider truncate" style={{ fontFamily: 'Orbitron' }}>
               GodWith<span className="text-primary">You</span>
             </h1>
          </div>
          <button onClick={() => setMobileOpen(false)} className="lg:hidden text-slate-400 hover:text-white shrink-0"><X size={24} /></button>
        </div>
        
        <div className="px-3 py-4 overflow-y-auto h-[calc(100%-80px)] flex flex-col gap-1 custom-scrollbar">
          <div className="mb-6">
            <p className="px-4 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-3">Core Engines</p>
            {navs.map(n => (
              <SidebarItem 
                key={n.to} 
                to={n.to} 
                icon={n.icon} 
                label={n.label} 
                active={location.pathname === n.to} 
              />
            ))}
          </div>
          
          <div className="mt-auto pt-4 border-t border-white/5">
            <button 
                onClick={() => setRestMode(true)}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-emerald-400 hover:bg-emerald-500/10 transition-all group mb-2 border border-dashed border-emerald-500/30 hover:border-emerald-500/60"
            >
                <BatteryCharging size={20} className="animate-pulse"/>
                <span className="font-medium text-sm">Recharge</span>
            </button>

            <p className="px-4 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-3">System</p>
            {bottoms.map(n => (
              <SidebarItem 
                key={n.to} 
                to={n.to} 
                icon={n.icon} 
                label={n.label} 
                active={location.pathname === n.to} 
              />
            ))}
            <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-all mt-2 group">
              <LogOut size={20} className="group-hover:translate-x-1 transition-transform" />
              <span className="font-medium text-sm">Disconnect</span>
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};

const Layout = ({ children }: { children?: React.ReactNode }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { restMode, setRestMode } = useContext(AppContext);

  return (
    <div className="min-h-screen text-slate-200">
      {restMode && <RestOverlay onClose={() => setRestMode(false)} />}
      <Sidebar mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className="lg:ml-72 min-h-screen flex flex-col transition-all duration-300">
        <header className="lg:hidden p-4 glass-panel m-4 rounded-xl flex items-center justify-between sticky top-4 z-30">
          <div className="flex items-center gap-3">
             <div className="relative w-10 h-10 flex items-center justify-center bg-black/40 border-2 border-primary/50 rounded-lg shadow-[0_0_15px_rgba(139,92,246,0.3)] overflow-hidden shrink-0">
                 <div className="absolute inset-0 bg-primary/20 blur-md"></div>
                 <StarLogo />
             </div>
             <h1 className="font-bold text-white tracking-wide truncate" style={{ fontFamily: 'Orbitron' }}>
                 GodWith<span className="text-primary">You</span>
             </h1>
          </div>
          <button onClick={() => setMobileOpen(true)} className="p-2 text-slate-300"><Menu /></button>
        </header>
        <main className="flex-1 p-4 lg:p-8 lg:pr-12 max-w-7xl w-full mx-auto">
          {children}
        </main>
        <WhisperAI />
      </div>
    </div>
  );
};

const ProtectedRoute = ({ children }: { children?: React.ReactNode }) => {
  const { user, isLoading } = useContext(AppContext);
  if (isLoading) return (
    <div className="flex flex-col h-screen items-center justify-center text-primary">
       <Sparkles className="animate-spin mb-4" size={40} />
       <p className="font-mono text-sm tracking-widest uppercase">Initializing Neural Link...</p>
    </div>
  );
  if (!user) return <Navigate to={AppRoute.LOGIN} replace />;
  return <Layout>{children}</Layout>;
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [restMode, setRestMode] = useState(false);

  useEffect(() => {
    // Check for active session
    const activeUser = DB.getUser();
    if (activeUser) {
        // Also check/update streaks on load
        DB.checkStreak();
        setUser(activeUser);
    }
    setIsLoading(false);
  }, []);

  return (
    <AppContext.Provider value={{ user, setUser, isLoading, restMode, setRestMode }}>
      <NeuroSyncProvider>
        <HashRouter>
          <Routes>
            <Route path={AppRoute.LOGIN} element={<Auth />} />
            <Route path={AppRoute.DASHBOARD} element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path={AppRoute.TIMELINE} element={<ProtectedRoute><Timeline /></ProtectedRoute>} />
            <Route path={AppRoute.DECISIONS} element={<ProtectedRoute><Decisions /></ProtectedRoute>} />
            <Route path={AppRoute.WORKSPACE} element={<ProtectedRoute><Workspace /></ProtectedRoute>} />
            <Route path={AppRoute.SENSE} element={<ProtectedRoute><Sense /></ProtectedRoute>} />
            <Route path={AppRoute.EMOTIONS} element={<ProtectedRoute><Emotions /></ProtectedRoute>} />
            <Route path={AppRoute.KNOWLEDGE} element={<ProtectedRoute><Knowledge /></ProtectedRoute>} />
            <Route path={AppRoute.CHAT} element={<ProtectedRoute><Chat /></ProtectedRoute>} />
            <Route path={AppRoute.PROJECTS} element={<ProtectedRoute><Projects /></ProtectedRoute>} />
            <Route path="/projects/:id" element={<ProtectedRoute><ProjectDetails /></ProtectedRoute>} />
            <Route path={AppRoute.HISTORY} element={<ProtectedRoute><HistoryPage /></ProtectedRoute>} />
            <Route path={AppRoute.PROFILE} element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path={AppRoute.HELP} element={<ProtectedRoute><Help /></ProtectedRoute>} />
            <Route path={AppRoute.FEEDBACK} element={<ProtectedRoute><Feedback /></ProtectedRoute>} />
            <Route path={AppRoute.STRIKES} element={<ProtectedRoute><Strikes /></ProtectedRoute>} />
            <Route path="/strikes/:id" element={<ProtectedRoute><StrikeDetails /></ProtectedRoute>} />
            <Route path="*" element={<Navigate to={AppRoute.DASHBOARD} replace />} />
          </Routes>
        </HashRouter>
      </NeuroSyncProvider>
    </AppContext.Provider>
  );
}