# GodWithYou - AI Life OS

## Overview

GodWithYou is an AI-powered "Human Operating System" - a personal productivity and life management application that integrates with Google's Gemini AI to provide intelligent assistance across various life domains. The application features timeline tracking, decision analysis, emotional logging, project management, knowledge base queries, and an AI chat interface with multiple interaction modes.

The system is designed around a "digital twin" concept where the AI learns user patterns and provides personalized guidance through specialized AI personas (ASTRA for knowledge, LUMA for emotions, FLOW for tasks, CORE for actions).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 19 with TypeScript
- **Build Tool**: Vite 6 with React plugin
- **Routing**: React Router DOM 6.22.3 (HashRouter for client-side routing)
- **Styling**: Tailwind CSS (loaded via CDN with custom configuration)
- **Icons**: Lucide React
- **State Management**: React Context API (AppContext for global user state)

### Component Structure
- `App.tsx` - Main application shell with routing and global context
- `pages/` - Route-level components (Dashboard, Chat, Projects, etc.)
- `components/` - Reusable UI components (RestOverlay, NeuroSyncProvider)
- `services/` - Business logic layer (AI integration, data persistence)

### Data Storage
- **Client-Side Only**: All data stored in browser localStorage
- **User Isolation**: Data keys are prefixed with user ID (`gwy_{dataType}_{userId}`)
- **No Backend Database**: The application is entirely client-side
- **Global Data**: Some shared data (user directory, public strikes) stored without user prefix

### AI Integration
- **Provider**: Google Gemini AI via `@google/genai` SDK
- **Models Used**: 
  - `gemini-2.5-flash` - Standard generation
  - `gemini-2.5-flash-preview-05-20` - Thinking mode (deep reasoning)
  - `gemini-2.0-flash-live-001` - Live/streaming sessions
  - `gemini-2.0-flash-exp` - Image generation
- **Features**: Text generation, JSON structured output, image analysis, audio transcription, speech synthesis, grounded search, live sessions

### Authentication
- **Simulated Auth**: Simple email/password stored in localStorage
- **No Real Authentication**: User credentials are stored locally, no server validation
- **Session Management**: Active user ID stored in localStorage

### Key Design Patterns
- **Brain Classification**: User input is classified into types (ASTRA/LUMA/FLOW/CORE) for appropriate handling
- **NeuroSync**: Activity monitoring system that tracks user cognitive load based on interactions
- **Digital Twin**: User profile that evolves based on activity and AI analysis

## External Dependencies

### AI Services
- **Google Gemini API**: Primary AI backend for all intelligence features
  - Requires `GEMINI_API_KEY` environment variable or user-provided API key
  - Used for: content generation, decision analysis, timeline predictions, chat, image generation/analysis, audio processing

### Frontend Libraries
- **React 19**: UI framework
- **React Router DOM**: Client-side routing
- **Lucide React**: Icon library
- **Tailwind CSS**: Utility-first CSS (loaded via CDN, not installed as dependency)

### Build & Development
- **Vite**: Development server and build tool
- **TypeScript**: Type checking (configured in tsconfig.json)

### Deployment
- **Vercel**: Configured via `vercel.json` with SPA rewrites
- **Static Hosting Compatible**: No server-side requirements