import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { Activity, Zap, Wind, AlertTriangle } from 'lucide-react';

// Types
export type NeuroState = 'FLOW' | 'FOCUS' | 'OVERLOAD';

interface NeuroSyncContextType {
  load: number;
  state: NeuroState;
}

export const NeuroSyncContext = createContext<NeuroSyncContextType>({ load: 0, state: 'FLOW' });

export const NeuroSyncProvider = ({ children }: { children?: React.ReactNode }) => {
  const [load, setLoad] = useState(0);
  const activityQueue = useRef<number[]>([]);

  useEffect(() => {
    // Activity Listeners
    const recordActivity = () => {
        const now = Date.now();
        activityQueue.current.push(now);
    };

    // Throttle mousemove to avoid noise
    let lastMove = 0;
    const handleMove = () => {
        const now = Date.now();
        if (now - lastMove > 500) {
            recordActivity();
            lastMove = now;
        }
    }

    window.addEventListener('keydown', recordActivity);
    window.addEventListener('click', recordActivity);
    window.addEventListener('scroll', recordActivity);
    window.addEventListener('mousemove', handleMove);

    // Engine Loop (1Hz)
    const interval = setInterval(() => {
        const now = Date.now();
        // Window size: 10 seconds for real-time responsiveness
        const windowSize = 10000; 
        activityQueue.current = activityQueue.current.filter(t => now - t < windowSize);
        
        const count = activityQueue.current.length;
        
        // Heuristic:
        // < 5 actions / 10s = Idle/Flow (Reading, thinking)
        // 5 - 20 actions = Focus (Working)
        // > 20 actions = Overload (Frantic clicking, rapid typing)
        let rawLoad = Math.min(100, (count / 25) * 100);
        
        setLoad(prev => {
            // Smooth interpolation
            const delta = rawLoad - prev;
            return Math.round(prev + (delta * 0.15));
        });

    }, 1000);

    return () => {
        window.removeEventListener('keydown', recordActivity);
        window.removeEventListener('click', recordActivity);
        window.removeEventListener('scroll', recordActivity);
        window.removeEventListener('mousemove', handleMove);
        clearInterval(interval);
    };
  }, []);

  // Derive NeuroState
  let state: NeuroState = 'FLOW';
  if (load > 75) state = 'OVERLOAD';
  else if (load > 30) state = 'FOCUS';

  // Apply System-wide Adaptations via CSS Variables
  useEffect(() => {
      const root = document.documentElement;
      
      if (state === 'OVERLOAD') {
          // High Cognitive Load -> Reduce noise, high contrast, stop distractions
          root.style.setProperty('--neuro-anim-speed', '60s'); // Freeze/Slow ambient
          root.style.setProperty('--neuro-opacity', '0.2'); // Dim decorations significantly
          root.style.setProperty('--neuro-contrast', '1.05'); // Slight contrast boost
          root.style.setProperty('--neuro-brightness', '0.9'); // Dim brightness to reduce glare
          root.style.setProperty('--neuro-blur', '0px'); // Remove blur effects for clarity
      } else if (state === 'FOCUS') {
          // Active work -> Focused UI
          root.style.setProperty('--neuro-anim-speed', '10s'); // Slow ambient
          root.style.setProperty('--neuro-opacity', '0.5'); // Moderate decorations
          root.style.setProperty('--neuro-contrast', '1.0');
          root.style.setProperty('--neuro-brightness', '1.0');
          root.style.setProperty('--neuro-blur', '10px');
      } else {
          // Flow/Idle -> Dreamy, ambient
          root.style.setProperty('--neuro-anim-speed', '4s'); // Standard pulse
          root.style.setProperty('--neuro-opacity', '0.8'); // Full decorations
          root.style.setProperty('--neuro-contrast', '1.0');
          root.style.setProperty('--neuro-brightness', '1.1'); // Bright and airy
          root.style.setProperty('--neuro-blur', '20px');
      }
      
  }, [state]);

  return (
      <NeuroSyncContext.Provider value={{ load, state }}>
          {/* NeuroSync HUD Overlay */}
          <div className="fixed top-0 inset-x-0 h-0.5 z-[100] transition-all duration-1000 ease-in-out" 
               style={{
                   background: state === 'OVERLOAD' ? '#f87171' : state === 'FOCUS' ? '#22d3ee' : '#a78bfa',
                   boxShadow: `0 0 ${load/2}px ${state === 'OVERLOAD' ? '#f87171' : state === 'FOCUS' ? '#22d3ee' : '#a78bfa'}`,
                   opacity: load > 0 ? 0.6 : 0,
                   width: `${load}%`
               }}
          />
          
          {/* Interactive Status Indicator with Tooltip */}
          <div className="fixed bottom-3 left-4 z-40 group cursor-help">
             <div className="flex items-center gap-2 opacity-40 mix-blend-screen transition-opacity group-hover:opacity-100 bg-black/20 p-2 rounded-full border border-transparent group-hover:border-white/10 backdrop-blur-sm">
                <div className={`w-2 h-2 rounded-full ${state === 'OVERLOAD' ? 'bg-red-500 animate-ping' : state === 'FOCUS' ? 'bg-cyan-500' : 'bg-purple-500 animate-pulse'}`}></div>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">
                    NeuroSync: {state} <span className="text-slate-600">[{load}%]</span>
                </span>
             </div>

             {/* Explanation Tooltip */}
             <div className="absolute bottom-full left-0 mb-4 w-72 p-5 bg-slate-900/95 border border-white/10 rounded-2xl backdrop-blur-xl opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all pointer-events-none shadow-2xl">
                 <div className="flex items-center gap-2 mb-3 text-white font-bold uppercase tracking-widest text-xs border-b border-white/10 pb-2">
                     <Activity size={14} className="text-primary"/> Adaptive UI Engine
                 </div>
                 <p className="text-slate-400 text-xs leading-relaxed mb-4 font-light">
                     NeuroSync monitors your interaction intensity (mouse, scroll, typing) to estimate cognitive load and adapts the interface to optimize your mental state.
                 </p>
                 <div className="space-y-2 text-[10px] font-mono">
                     <div className={`flex items-center gap-3 p-2 rounded-lg border ${state === 'FLOW' ? 'bg-purple-500/10 border-purple-500/30' : 'border-transparent opacity-50'}`}>
                         <Wind size={12} className="text-purple-400"/>
                         <div>
                             <span className="text-purple-400 font-bold block">FLOW (0-30%)</span>
                             <span className="text-slate-500">Enhanced aesthetics for creativity.</span>
                         </div>
                     </div>
                     <div className={`flex items-center gap-3 p-2 rounded-lg border ${state === 'FOCUS' ? 'bg-cyan-500/10 border-cyan-500/30' : 'border-transparent opacity-50'}`}>
                         <Zap size={12} className="text-cyan-400"/>
                         <div>
                             <span className="text-cyan-400 font-bold block">FOCUS (30-75%)</span>
                             <span className="text-slate-500">Balanced clarity for productivity.</span>
                         </div>
                     </div>
                     <div className={`flex items-center gap-3 p-2 rounded-lg border ${state === 'OVERLOAD' ? 'bg-red-500/10 border-red-500/30' : 'border-transparent opacity-50'}`}>
                         <AlertTriangle size={12} className="text-red-400"/>
                         <div>
                             <span className="text-red-400 font-bold block">OVERLOAD (75%+)</span>
                             <span className="text-slate-500">Reduced noise & contrast for calm.</span>
                         </div>
                     </div>
                 </div>
             </div>
          </div>

          {children}
      </NeuroSyncContext.Provider>
  );
};