import React, { useEffect, useState, useContext } from 'react';
import { AppContext } from '../App';
import * as DB from '../services/db';
import * as AI from '../services/ai';
import { Battery, Brain, Activity, Sun, Sparkles, RefreshCw, Send, Orbit, AlertTriangle, Flame, Trophy, Zap } from 'lucide-react';

export default function Dashboard() {
  const { user, setUser, setRestMode } = useContext(AppContext);
  const [input, setInput] = useState('');
  const [processing, setProcessing] = useState(false);
  const [processedResult, setProcessedResult] = useState<{type: string, message: string, error?: boolean} | null>(null);
  const [updatingTwin, setUpdatingTwin] = useState(false);

  // FlowState Data
  const twin = user?.digitalTwin;

  useEffect(() => {
     // Re-fetch user on mount to ensure stats are fresh (streak updates)
     const u = DB.getUser();
     if(u && JSON.stringify(u.stats) !== JSON.stringify(user?.stats)) {
         setUser(u);
     }
  }, []);

  const handleUniversalInput = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    setProcessing(true);
    setProcessedResult(null);

    try {
      // 1. Classify
      const brain = await AI.classifyInput(input);
      
      // 2. Action based on Brain
      let message = "";
      
      // Check for silent failure (empty JSON return often means error in services/ai.ts)
      if (!brain) {
           throw new Error("Neural Link Unresponsive");
      }

      if (brain === 'CORE') {
         // Auto-create task in a generic inbox project
         const projects = DB.getProjects();
         let inbox = projects.find(p => p.name === 'Inbox');
         if (!inbox) {
             inbox = { id: 'inbox', name: 'Inbox', description: 'Quick Capture', status: 'active', progress: 0, tasks: [] };
             DB.saveProject(inbox);
         }
         const task = { id: crypto.randomUUID(), title: input, completed: false, priority: 'medium' as const, dueDate: new Date().toISOString().split('T')[0] };
         inbox.tasks.push(task);
         DB.saveProject(inbox);
         
         // Trigger streak update
         DB.checkStreak();
         const updatedUser = DB.getUser();
         if(updatedUser) setUser(updatedUser);

         message = "CORE: Task intercepted and deployed to Inbox.";
      } else if (brain === 'LUMA') {
         // Log emotion
         DB.addEmotion({ id: crypto.randomUUID(), mood: 5, energy: 50, labels: ['Auto-Log'], note: input, timestamp: Date.now() });
         message = "LUMA: Emotional resonance logged. Calibrating recovery.";
      } else if (brain === 'ASTRA') {
         // Create knowledge node
         DB.addKnowledge({ id: crypto.randomUUID(), query: input, summary: 'Pending Analysis', explanation: '', sources: [], timestamp: Date.now() });
         message = "ASTRA: Query captured in knowledge matrix.";
      } else {
         message = "FLOW: Idea archived in creative banks.";
      }
      
      setProcessedResult({ type: brain, message });
      setInput('');
    } catch (e) {
      console.error(e);
      setProcessedResult({ type: 'ERROR', message: 'Neural Link Offline. Check API Key configuration.', error: true });
    }
    setProcessing(false);
  };

  const handleSyncTwin = async () => {
    if (!user?.apiKey && !process.env.API_KEY) {
        setProcessedResult({ type: 'ERROR', message: 'API Key Required for Synchronization.', error: true });
        return;
    }
    setUpdatingTwin(true);
    try {
        const twinData = await AI.updateDigitalTwin();
        if (twinData && user) {
            setUser({...user, digitalTwin: twinData});
        }
    } catch (e) {
        console.error("Twin sync failed", e);
    }
    setUpdatingTwin(false);
  };

  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center relative animate-fade-in overflow-hidden rounded-3xl">
      
      {/* 3D FlowState Portal Visualization (CSS driven) */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0 overflow-hidden">
          <div className="w-[600px] h-[600px] border border-white/5 rounded-full animate-orbit opacity-30"></div>
          <div className="absolute w-[400px] h-[400px] border border-dashed border-primary/20 rounded-full animate-orbit opacity-40" style={{animationDirection: 'reverse', animationDuration: '30s'}}></div>
          <div className="absolute w-[800px] h-[800px] border border-white/5 rounded-full animate-pulse-slow opacity-20"></div>
      </div>

      {/* Central Command Node */}
      <div className="relative z-10 w-full max-w-2xl text-center space-y-10 py-12">
          
          <div className="flex flex-col items-center gap-6">
               <div className="relative group cursor-pointer" onClick={handleSyncTwin}>
                   <div className="absolute inset-0 bg-primary/40 blur-2xl rounded-full animate-pulse-slow"></div>
                   <div className="w-24 h-24 bg-black/50 backdrop-blur-md border-2 border-primary/50 rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(139,92,246,0.3)] transition-transform group-hover:scale-110 relative z-10">
                       {updatingTwin ? <RefreshCw className="animate-spin text-white"/> : <Brain size={40} className="text-white"/>}
                   </div>
                   <div className="absolute -top-1 -right-2 bg-emerald-500 text-[10px] font-bold text-black px-2 py-0.5 rounded-full border border-white/20 z-20 shadow-lg">
                       LVL {twin?.evolutionLevel || 1}
                   </div>
                   <div className="mt-4 text-center">
                       <h2 className="text-xs font-bold text-slate-400 uppercase tracking-[0.3em] mb-1">System Online</h2>
                   </div>
               </div>
              
              <div className="space-y-2">
                  <h1 className="text-4xl md:text-5xl font-bold text-white font-sans tracking-tight">
                      Welcome, <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">{user?.name}</span>
                  </h1>
                  <p className="text-slate-400 font-light text-lg max-w-lg mx-auto leading-relaxed">
                      "{twin?.personalitySummary || "Neural synchronization pending. Please initialize."}"
                  </p>
              </div>
          </div>

          {/* Universal Input Box */}
          <div className="relative group max-w-xl mx-auto w-full">
              <div className="absolute inset-0 bg-gradient-to-r from-primary via-secondary to-primary opacity-30 blur-xl rounded-2xl group-hover:opacity-50 transition-opacity"></div>
              <form onSubmit={handleUniversalInput} className="relative bg-black/60 backdrop-blur-xl border border-white/20 rounded-2xl p-2 flex items-center shadow-2xl">
                  <input 
                    className="flex-1 bg-transparent px-6 py-4 text-lg text-white placeholder-slate-500 focus:outline-none font-light"
                    placeholder="Input thought, task, or emotion..."
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    disabled={processing}
                  />
                  <button disabled={processing} className="p-4 bg-white/10 hover:bg-white/20 rounded-xl text-white transition-all">
                      {processing ? <RefreshCw className="animate-spin" /> : <Send />}
                  </button>
              </form>
              
              {/* Feedback Message */}
              {processedResult && (
                  <div className="absolute -bottom-16 left-0 right-0 text-center animate-slide-up">
                      <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full border backdrop-blur-md ${processedResult.error ? 'bg-red-500/10 border-red-500/30 text-red-400' : 'bg-white/5 border-white/10'}`}>
                          {processedResult.error ? <AlertTriangle size={12} /> : <span className="w-2 h-2 rounded-full bg-secondary animate-pulse"></span>}
                          {!processedResult.error && <span className="text-xs font-bold text-secondary uppercase">{processedResult.type}</span>}
                          <span className="text-xs border-l border-white/10 pl-2 opacity-90">{processedResult.message}</span>
                      </div>
                  </div>
              )}
          </div>

          {/* Floating Orbit Nodes (Live Stats) */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 w-full">
              {[
                  { label: 'Energy', icon: Battery, val: `${user?.stats.energyScore || 50}%`, color: 'text-emerald-400', action: () => setRestMode(true) },
                  { label: 'Streak', icon: Flame, val: `${user?.stats.currentStreak || 0} Day`, color: 'text-orange-400', action: null },
                  { label: 'XP', icon: Trophy, val: `${user?.stats.xp || 0}`, color: 'text-yellow-400', action: null },
                  { label: 'Focus', icon: Zap, val: 'Ready', color: 'text-cyan-400', action: null }
              ].map((item, i) => (
                  <div 
                    key={i} 
                    onClick={item.action ? item.action : undefined}
                    className={`glass-card p-4 rounded-xl flex flex-col items-center justify-center gap-2 border border-white/5 hover:border-white/20 group ${item.action ? 'cursor-pointer hover:bg-white/5' : ''}`}
                  >
                      <item.icon className={`${item.color} w-6 h-6 group-hover:scale-110 transition-transform`} />
                      <span className="text-xl font-bold text-white font-sans">{item.val}</span>
                      <span className="text-[10px] uppercase tracking-widest text-slate-500">{item.label}</span>
                  </div>
              ))}
          </div>

      </div>
    </div>
  );
}