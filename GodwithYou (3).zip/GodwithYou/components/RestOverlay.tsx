
import React, { useEffect, useState } from 'react';
import { X, BatteryCharging, Wind } from 'lucide-react';
import * as DB from '../services/db';

interface RestOverlayProps {
  onClose: () => void;
  durationMinutes?: number;
}

export default function RestOverlay({ onClose, durationMinutes = 5 }: RestOverlayProps) {
  const [timeLeft, setTimeLeft] = useState(durationMinutes * 60);
  const [phase, setPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [completed, setCompleted] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          setCompleted(true);
          DB.updateEnergyScore(15); // Bonus energy
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Breathing Cycle (4-4-4)
    const breathTimer = setInterval(() => {
      setPhase(p => {
        if (p === 'inhale') return 'hold';
        if (p === 'hold') return 'exhale';
        return 'inhale';
      });
    }, 4000);

    return () => {
      clearInterval(timer);
      clearInterval(breathTimer);
    };
  }, []);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center animate-fade-in">
      <button onClick={onClose} className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors">
        <X size={32} />
      </button>

      {!completed ? (
        <>
          <div className="relative mb-12">
            {/* Breathing Orb */}
            <div className={`w-64 h-64 rounded-full bg-gradient-to-br from-secondary/40 to-primary/40 blur-3xl absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transition-all duration-[4000ms] ${
                phase === 'inhale' ? 'scale-150 opacity-80' : phase === 'hold' ? 'scale-125 opacity-60' : 'scale-100 opacity-40'
            }`}></div>
            
            <div className={`w-40 h-40 rounded-full border-2 border-white/20 flex items-center justify-center relative z-10 bg-black/30 backdrop-blur-sm transition-all duration-[4000ms] ${
                 phase === 'inhale' ? 'scale-110 border-secondary' : phase === 'hold' ? 'border-white' : 'scale-90 border-primary'
            }`}>
                 <span className="text-4xl font-bold text-white font-mono">{formatTime(timeLeft)}</span>
            </div>
          </div>

          <h2 className="text-3xl font-bold text-white mb-2 font-sans tracking-widest uppercase animate-pulse">
            {phase === 'inhale' ? 'Inhale deeply...' : phase === 'hold' ? 'Hold...' : 'Exhale slowly...'}
          </h2>
          <p className="text-slate-400 font-light">Sync your biology with the cosmos.</p>
        </>
      ) : (
        <div className="text-center animate-slide-up">
           <div className="w-24 h-24 mx-auto bg-emerald-500/20 rounded-full flex items-center justify-center mb-6 border border-emerald-500/50 shadow-[0_0_40px_rgba(16,185,129,0.4)]">
               <BatteryCharging size={40} className="text-emerald-400" />
           </div>
           <h2 className="text-4xl font-bold text-white mb-4">System Recharged</h2>
           <p className="text-slate-400 mb-8">Energy levels optimized. Cognitive load cleared.</p>
           <button onClick={onClose} className="neon-button px-8 py-3 rounded-xl text-white font-bold uppercase tracking-widest">
               Resume Flow
           </button>
        </div>
      )}
    </div>
  );
}
