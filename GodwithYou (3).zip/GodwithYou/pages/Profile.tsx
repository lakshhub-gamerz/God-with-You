import React, { useContext } from 'react';
import { AppContext } from '../App';
import { UserCircle, Shield, Clock, Zap, Flame, Trophy, Activity } from 'lucide-react';

export default function Profile() {
  const { user } = useContext(AppContext);

  return (
    <div className="max-w-4xl mx-auto mt-10 animate-fade-in pb-20">
        <div className="relative mb-12 text-center">
            <div className="w-32 h-32 glass-panel rounded-full mx-auto mb-6 flex items-center justify-center text-slate-500 shadow-[0_0_50px_rgba(139,92,246,0.2)] border-2 border-primary/20 relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-secondary/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                {user?.avatar ? <img src={user.avatar} className="w-full h-full rounded-full object-cover" /> : <UserCircle size={64} className="text-slate-400"/>}
            </div>
            <h1 className="text-4xl font-bold text-white mb-2 font-sans tracking-wide">{user?.name}</h1>
            <p className="text-primary font-mono text-sm tracking-widest uppercase">{user?.email}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            {/* Identity Matrix */}
            <div className="glass-panel p-8 rounded-3xl border border-white/10 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[80px]"></div>
                <div className="relative z-10">
                    <h3 className="text-xs font-bold text-slate-500 uppercase tracking-[0.2em] mb-6 border-b border-white/5 pb-2">Identity Matrix</h3>
                    <div className="space-y-6">
                        <div className="flex items-center gap-4 p-4 bg-white/5 rounded-xl border border-white/5">
                            <div className="p-3 bg-secondary/10 rounded-lg text-secondary"><Shield size={24}/></div>
                            <div>
                                <label className="block text-xs text-slate-400 uppercase tracking-wider mb-1">Clearance Level</label>
                                <p className="text-white font-bold font-sans">Admin / Architect</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-4 p-4 bg-white/5 rounded-xl border border-white/5">
                            <div className="p-3 bg-primary/10 rounded-lg text-primary"><Clock size={24}/></div>
                            <div>
                                <label className="block text-xs text-slate-400 uppercase tracking-wider mb-1">System Entry</label>
                                <p className="text-white font-bold font-sans">{new Date().toLocaleDateString()}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Performance Stats */}
            <div className="glass-panel p-8 rounded-3xl border border-white/10 relative overflow-hidden">
                <div className="absolute bottom-0 left-0 w-64 h-64 bg-secondary/5 rounded-full blur-[80px]"></div>
                <div className="relative z-10">
                    <h3 className="text-xs font-bold text-slate-500 uppercase tracking-[0.2em] mb-6 border-b border-white/5 pb-2">Performance Metrics</h3>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-orange-500/10 rounded-xl border border-orange-500/20 text-center">
                            <Flame className="text-orange-500 mx-auto mb-2" size={24}/>
                            <div className="text-2xl font-bold text-white">{user?.stats.currentStreak}</div>
                            <div className="text-[10px] uppercase text-orange-400 font-bold">Current Streak</div>
                        </div>
                         <div className="p-4 bg-yellow-500/10 rounded-xl border border-yellow-500/20 text-center">
                            <Trophy className="text-yellow-500 mx-auto mb-2" size={24}/>
                            <div className="text-2xl font-bold text-white">{user?.stats.longestStreak}</div>
                            <div className="text-[10px] uppercase text-yellow-400 font-bold">Best Streak</div>
                        </div>
                         <div className="p-4 bg-purple-500/10 rounded-xl border border-purple-500/20 text-center">
                            <Zap className="text-purple-500 mx-auto mb-2" size={24}/>
                            <div className="text-2xl font-bold text-white">{user?.stats.xp}</div>
                            <div className="text-[10px] uppercase text-purple-400 font-bold">Total XP</div>
                        </div>
                         <div className="p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-center">
                            <Activity className="text-emerald-500 mx-auto mb-2" size={24}/>
                            <div className="text-2xl font-bold text-white">{user?.stats.energyScore}%</div>
                            <div className="text-[10px] uppercase text-emerald-400 font-bold">Energy</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
}