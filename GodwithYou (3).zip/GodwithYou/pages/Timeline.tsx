import React, { useState, useEffect } from 'react';
import * as DB from '../services/db';
import { TimelineEvent } from '../types';
import { Plus, Trash2, Zap, GitCommitVertical } from 'lucide-react';
import { generateJSON } from '../services/ai';

export default function Timeline() {
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [newEvent, setNewEvent] = useState<Partial<TimelineEvent>>({ type: 'past', impact: 'neutral' });

  useEffect(() => {
    setEvents(DB.getTimeline().sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
  }, []);

  const handleAdd = () => {
    if (!newEvent.title || !newEvent.date) return;
    const event: TimelineEvent = {
      id: crypto.randomUUID(),
      title: newEvent.title!,
      date: newEvent.date!,
      description: newEvent.description || '',
      type: newEvent.type as any,
      impact: newEvent.impact as any,
      category: newEvent.category || 'Life'
    };
    DB.saveTimelineEvent(event);
    setEvents(prev => [...prev, event].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
    setShowAdd(false);
    setNewEvent({ type: 'past', impact: 'neutral' });
  };

  const predictFuture = async () => {
    setLoading(true);
    const context = events.map(e => `${e.date}: ${e.title} (${e.impact})`).join('\n');
    const prompt = `
        Based on this life timeline:\n${context}
        
        Predict 2 plausible future major life events for the next 5 years based on the trajectory.
        Return JSON object with key "predictions" containing an array of objects with keys: title, date (YYYY-MM-DD), description, category.
    `;
    
    try {
        const data = await generateJSON(prompt);
        if (data.predictions && Array.isArray(data.predictions)) {
            const newPredictions: TimelineEvent[] = data.predictions.map((p: any) => ({
                id: crypto.randomUUID(),
                title: p.title,
                date: p.date,
                description: p.description,
                type: 'prediction',
                impact: 'positive',
                category: p.category || 'Future'
            }));
            
            newPredictions.forEach(p => DB.saveTimelineEvent(p));
            setEvents(prev => [...prev, ...newPredictions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()));
        }
    } catch (e) {
        console.error(e);
    }
    setLoading(false);
  };

  const handleDelete = (id: string) => {
    if(!confirm("Delete this event from the timeline?")) return;
    const newEvents = events.filter(e => e.id !== id);
    localStorage.setItem('gwy_timeline', JSON.stringify(newEvents));
    setEvents(newEvents);
  };

  return (
    <div className="h-full relative animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-end md:items-center mb-10 gap-4">
        <div>
          <h1 className="text-4xl font-bold text-white mb-2 tracking-tight shadow-purple-500/50 drop-shadow-lg">Timeline Engine</h1>
          <p className="text-secondary/80 font-mono text-sm">Temporal Visualization & Probability Waves</p>
        </div>
        <div className="flex gap-4">
          <button onClick={predictFuture} disabled={loading} className="neon-button px-6 py-2 text-white rounded-lg flex items-center gap-2 transition-all hover:scale-105 disabled:opacity-50">
            <Zap size={18} className={loading ? 'animate-spin' : ''} /> {loading ? 'Computing...' : 'Extrapolate Future'}
          </button>
          <button onClick={() => setShowAdd(!showAdd)} className="px-6 py-2 bg-slate-800/50 hover:bg-slate-700/50 border border-white/10 text-white rounded-lg flex items-center gap-2 transition-all backdrop-blur-md">
            <Plus size={18} /> Add Node
          </button>
        </div>
      </div>

      {showAdd && (
        <div className="mb-8 p-6 glass-panel rounded-xl animate-fade-in border-t border-primary/30">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <input placeholder="Title" className="holo-input p-3 rounded-lg" value={newEvent.title || ''} onChange={e => setNewEvent({...newEvent, title: e.target.value})} />
            <input type="date" className="holo-input p-3 rounded-lg" value={newEvent.date || ''} onChange={e => setNewEvent({...newEvent, date: e.target.value})} />
            <select className="holo-input p-3 rounded-lg" value={newEvent.type} onChange={e => setNewEvent({...newEvent, type: e.target.value as any})}>
              <option value="past">Recorded Past</option>
              <option value="goal">Target Goal</option>
            </select>
            <input placeholder="Category" className="holo-input p-3 rounded-lg" value={newEvent.category || ''} onChange={e => setNewEvent({...newEvent, category: e.target.value})} />
          </div>
          <textarea placeholder="Event Description Data..." className="w-full holo-input p-3 rounded-lg mb-4 h-24 resize-none" value={newEvent.description || ''} onChange={e => setNewEvent({...newEvent, description: e.target.value})} />
          <div className="flex justify-end gap-2">
            <button onClick={() => setShowAdd(false)} className="px-4 py-2 text-slate-400 hover:text-white">Cancel</button>
            <button onClick={handleAdd} className="px-6 py-2 bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 hover:bg-emerald-500/30 rounded-lg transition-all">Commit Node</button>
          </div>
        </div>
      )}

      {/* Futuristic Vertical Line */}
      <div className="relative border-l-2 border-primary/30 ml-4 md:ml-8 space-y-12 py-4">
        {/* Glowing laser beam effect on the line */}
        <div className="absolute top-0 bottom-0 -left-[2px] w-[2px] bg-gradient-to-b from-transparent via-primary to-transparent shadow-[0_0_15px_#8b5cf6]"></div>

        {events.map((event) => (
          <div key={event.id} className="relative pl-8 md:pl-16 group">
            {/* Timeline Node */}
            <div className={`absolute -left-[11px] top-6 h-6 w-6 rounded-full border-2 bg-dark z-10 flex items-center justify-center transition-all duration-500 group-hover:scale-125 group-hover:shadow-[0_0_20px_currentColor] ${
              event.type === 'prediction' ? 'border-purple-500 text-purple-500' : 
              event.impact === 'positive' ? 'border-emerald-400 text-emerald-400' : 
              event.impact === 'negative' ? 'border-red-500 text-red-500' : 'border-slate-400 text-slate-400'
            }`}>
                <div className="w-2 h-2 rounded-full bg-current"></div>
            </div>
            
            {/* Connector Line */}
            <div className="absolute left-[13px] top-[34px] w-8 md:w-16 h-[1px] bg-gradient-to-r from-primary/50 to-transparent"></div>

            <div className="glass-card p-6 rounded-xl hover:border-primary/40 relative overflow-hidden group-hover:translate-x-2 transition-transform duration-300">
               {/* Background glow on hover */}
               <div className="absolute -right-10 -top-10 w-32 h-32 bg-primary/10 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
               
              <div className="flex justify-between items-start relative z-10">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                      <span className="font-mono text-xs text-primary/80">{event.date}</span>
                      <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                          event.type === 'prediction' ? 'border-purple-500/30 bg-purple-500/10 text-purple-400' : 'border-slate-700 bg-slate-800/50 text-slate-400'
                      }`}>
                        {event.type}
                      </span>
                  </div>
                  <h3 className="text-xl font-bold text-white font-sans tracking-wide">{event.title}</h3>
                  <p className="text-slate-400 mt-2 font-light leading-relaxed">{event.description}</p>
                </div>
                <button 
                  onClick={() => handleDelete(event.id)} 
                  className="text-slate-600 hover:text-red-400 opacity-60 hover:opacity-100 transition-all p-2 hover:bg-red-500/10 rounded-full"
                  title="Delete Event"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}