
import { GoogleGenAI, Modality, LiveServerMessage } from "@google/genai";
import { getUser, getSystemContext, saveUser } from "./db";

// --- ENVIRONMENT SAFETY HELPER ---
const getApiKey = (): string => {
  const user = getUser();
  if (user?.apiKey) return user.apiKey;

  // Extremely defensive check for process.env
  try {
    // Check if process exists and has env property
    const p = typeof process !== 'undefined' ? process : null;
    if (p && p.env && p.env.API_KEY) {
      return p.env.API_KEY;
    }
  } catch (e) {
    // Ignore error
  }

  // Extremely defensive check for import.meta.env
  try {
     // @ts-ignore
     if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_API_KEY) {
       // @ts-ignore
       return import.meta.env.VITE_API_KEY;
     }
  } catch (e) {
    // Ignore error
  }

  return '';
};

const getAI = () => {
  const apiKey = getApiKey();
  if (!apiKey) throw new Error("Neural Link Offline");
  return new GoogleGenAI({ apiKey });
};

// --- STANDARD GENERATION ---

export const generateContent = async (prompt: string, modelName: string = 'gemini-2.5-flash') => {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
    });
    return response.text || "Neural silence.";
  } catch (error: any) {
    console.error("AI Error:", error);
    if (error.message === "Neural Link Offline") {
        return "Connection failed: API Key missing.";
    }
    return "The system cannot process this request currently.";
  }
};

// --- SEARCH GROUNDING (GEMINI 2.5 FLASH) ---

export const generateGroundedContent = async (prompt: string) => {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    
    // Extract text and grounding metadata (urls)
    const text = response.text || "No data retrieved.";
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const urls = chunks
      .map((c: any) => c.web?.uri)
      .filter((u: string) => !!u);
      
    // Format output with sources
    let output = text;
    if (urls.length > 0) {
        output += "\n\nSOURCES:\n" + urls.slice(0, 3).map((u: string) => `- ${u}`).join('\n');
    }
    return output;

  } catch (error: any) {
    console.error("Grounding Error:", error);
    return "Unable to access the knowledge grid (Search failed).";
  }
};

// --- IMAGE GENERATION (GEMINI 3 PRO IMAGE) ---

export const generateImage = async (prompt: string, size: '1K' | '2K' | '4K' = '1K'): Promise<string | null> => {
    try {
        const ai = getAI();
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-image-preview',
            contents: {
                parts: [{ text: prompt }]
            },
            config: {
                imageConfig: {
                    imageSize: size,
                    aspectRatio: "1:1"
                }
            }
        });

        // Iterate parts to find image
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) {
                return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            }
        }
        return null;
    } catch (e) {
        console.error("Image Gen Error", e);
        return null;
    }
};

// --- VISION ANALYSIS (GEMINI 3 PRO) ---

export const analyzeImage = async (base64Data: string, mimeType: string, prompt: string) => {
    try {
        const ai = getAI();
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Data,
                            mimeType: mimeType
                        }
                    },
                    { text: prompt }
                ]
            }
        });
        return response.text || "Visual analysis complete: No distinct patterns found.";
    } catch (e) {
        console.error("Vision Error", e);
        return "Visual sensors offline.";
    }
};

// --- AUDIO TRANSCRIPTION (GEMINI 2.5 FLASH) ---

export const transcribeAudio = async (base64Data: string, mimeType: string) => {
    try {
        const ai = getAI();
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: base64Data,
                            mimeType: mimeType
                        }
                    },
                    { text: "Transcribe this audio exactly as spoken." }
                ]
            }
        });
        return response.text || "";
    } catch (e) {
        console.error("Transcription Error", e);
        return "Audio signal degraded.";
    }
};

// --- THINKING MODE (GEMINI 3 PRO) ---

export const generateThinkingResponse = async (prompt: string) => {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        thinkingConfig: {
            thinkingBudget: 32768, // Max budget for deep reasoning
        }
      }
    });
    return response.text || "Deep thought yielded no specific output.";
  } catch (error: any) {
    console.error("Thinking Error:", error);
    return "Cognitive overload in Thinking Mode. Try Standard Mode.";
  }
};

// --- TEXT TO SPEECH (GEMINI 2.5 FLASH TTS) ---

export const generateSpeech = async (text: string): Promise<string | null> => {
    try {
        const ai = getAI();
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-preview-tts',
            contents: { parts: [{ text }] },
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' }
                    }
                }
            }
        });
        
        // Extract base64 audio
        const base64 = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        return base64 || null;
    } catch (e) {
        console.error("TTS Error", e);
        return null;
    }
};

// Helper: Play Raw PCM Data from Gemini TTS
export const playAudioData = async (base64Audio: string) => {
    try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        
        // Decode base64 to binary
        const binaryString = atob(base64Audio);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        
        // Convert PCM (Int16) to Float32
        const dataInt16 = new Int16Array(bytes.buffer);
        const float32Data = new Float32Array(dataInt16.length);
        for (let i = 0; i < dataInt16.length; i++) {
            float32Data[i] = dataInt16[i] / 32768.0;
        }
        
        // Create AudioBuffer
        const buffer = audioContext.createBuffer(1, float32Data.length, 24000);
        buffer.getChannelData(0).set(float32Data);
        
        // Play
        const source = audioContext.createBufferSource();
        source.buffer = buffer;
        source.connect(audioContext.destination);
        source.start();
        
    } catch (e) {
        console.error("Audio Playback Error", e);
    }
};


export const generateJSON = async (prompt: string, model: string = 'gemini-2.5-flash') => {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt + "\n\nCRITICAL: Return ONLY valid JSON. No markdown formatting.",
      config: {
        responseMimeType: "application/json",
      }
    });
    
    let text = response.text || "{}";
    text = text.replace(/```json/g, '').replace(/```/g, '').trim();
    
    return JSON.parse(text);
  } catch (error: any) {
    console.error("AI JSON Error:", error);
    return {};
  }
};

// --- MULTI-BRAIN ROUTER (UPDATED TO FLASH-LITE FOR SPEED) ---

export const classifyInput = async (input: string): Promise<'LUMA' | 'ASTRA' | 'CORE' | 'FLOW'> => {
  const prompt = `
    Classify the user input into one of these brains:
    - LUMA: Emotional support, stress, mood, venting, personal feelings.
    - ASTRA: Knowledge, research, complex questions, how-to, learning workflows.
    - CORE: Task management, creating to-dos, scheduling, productivity, "remind me to".
    - FLOW: Creative ideas, brainstorming, art, writing concepts.
    
    Input: "${input}"
    Return JSON: { "brain": "LUMA" | "ASTRA" | "CORE" | "FLOW" }
  `;
  // Use Flash-Lite for low-latency classification
  const res = await generateJSON(prompt, 'gemini-2.5-flash-lite');
  return res.brain || 'CORE';
};

export const getWhisperResponse = async (input: string) => {
  try {
      // Use Flash-Lite for fast classification
      const brain = await classifyInput(input);
      const context = getSystemContext();
      
      let systemPrompt = "";
      if (brain === 'LUMA') systemPrompt = "You are LUMA, an emotional support AI. Be empathetic, calm, and soothing. Brief response.";
      if (brain === 'ASTRA') systemPrompt = "You are ASTRA, a knowledge engine. Be precise, logical, and structured. Brief response.";
      if (brain === 'CORE') systemPrompt = "You are CORE, a productivity OS. Be direct, actionable, and efficient. Brief response.";
      if (brain === 'FLOW') systemPrompt = "You are FLOW, a creative muse. Be inspiring, abstract, and energetic. Brief response.";

      const prompt = `${systemPrompt}\nUser Context: ${context}\nUser Input: ${input}`;
      
      // Use Flash-Lite for fast response generation
      const response = await generateContent(prompt, 'gemini-2.5-flash-lite');
      return { text: response, brain };
  } catch (e) {
      return { text: "Signal Interrupted.", brain: 'CORE' };
  }
};

// --- STRIKE ENGINES (ASTRA/LUMA) ---

export const generateStrikeGuidance = async (type: 'ASTRA' | 'LUMA', context: any) => {
    try {
        if (type === 'ASTRA') {
            const prompt = `
                Act as ASTRA, the tactical optimization AI.
                Context: User is doing a "${context.difficulty}" difficulty Strike: "${context.title}".
                Daily Goal: "${context.dailyGoal}".
                
                Generate 3 extremely concise, actionable micro-steps to achieve this daily goal efficiently.
                Return JSON: { "steps": ["Step 1", "Step 2", "Step 3"] }
            `;
            const data = await generateJSON(prompt, 'gemini-2.5-flash');
            return { type: 'ASTRA', content: data.steps || [] };
        } else {
             const prompt = `
                Act as LUMA, the emotional resilience AI.
                Context: User is on Day ${context.currentDay} of a ${context.durationDays}-day Strike: "${context.title}".
                Difficulty: ${context.difficulty}.
                
                Provide a short, profound, and motivating message (max 20 words) to keep them going.
            `;
            const text = await generateContent(prompt, 'gemini-2.5-flash');
            return { type: 'LUMA', content: text };
        }
    } catch (e) {
        return { type: 'ERROR', content: null };
    }
};

// --- CORE ENGINES ---

export const updateDigitalTwin = async () => {
    const context = getSystemContext();
    const prompt = `
        System Context: ${context}
        
        Act as the "GodwithYou" Core. Analyze the user's life patterns.
        Construct a high-fidelity "Digital Twin" personality profile.
        
        Return JSON:
        {
            "personalitySummary": "1-2 profound sentences describing their current state of being.",
            "coreValues": ["Value1", "Value2", "Value3"],
            "currentFocus": "The single most important theme in their data right now.",
            "evolutionLevel": (Integer 1-100 based on clarity/productivity/mood),
            "archetype": "A creative title for their persona (e.g. 'The Void Walker', 'The Architect')"
        }
    `;
    
    const data = await generateJSON(prompt);
    
    if (data.personalitySummary) {
        const user = getUser();
        if (user) {
            user.digitalTwin = {
                lastUpdate: Date.now(),
                personalitySummary: data.personalitySummary,
                coreValues: data.coreValues || [],
                currentFocus: data.currentFocus || "Unknown",
                evolutionLevel: data.evolutionLevel || 50,
                archetype: data.archetype || "The Traveler"
            };
            saveUser(user);
            return user.digitalTwin;
        }
    }
    return null;
};

export const findDuplicates = async (notes: {id: string, title: string, content: string}[]) => {
    if (notes.length < 2) return [];
    
    const simplified = notes.map(n => ({ id: n.id, text: `${n.title} ${n.content}`.substring(0, 150) }));
    const prompt = `
        Analyze these neural nodes (notes): ${JSON.stringify(simplified)}
        Identify clusters of semantically similar content.
        Return JSON array of arrays: [["id1", "id2"], ["id3", "id4"]]
        Return [] if no semantic overlaps found.
    `;
    
    const res = await generateJSON(prompt);
    return Array.isArray(res) ? res : [];
};

// --- LIVE SESSION (REAL-TIME VOICE) ---

export class LiveSession {
  private client: GoogleGenAI;
  private session: any = null;
  private inputContext: AudioContext | null = null;
  private outputContext: AudioContext | null = null;
  private inputSource: MediaStreamAudioSourceNode | null = null;
  private processor: ScriptProcessorNode | null = null;
  private nextStartTime: number = 0;
  private sources: Set<AudioBufferSourceNode> = new Set();
  public onStatusChange: (status: string) => void = () => {};

  constructor() {
    const apiKey = getApiKey();
    if (!apiKey) throw new Error("Neural Link Offline");
    this.client = new GoogleGenAI({ apiKey });
  }

  async connect() {
    this.onStatusChange("Initializing Neural Voice Link...");
    
    // Setup Audio
    this.inputContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    this.outputContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    
    // Connect to Gemini Live
    const sessionPromise = this.client.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-09-2025',
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
        },
        systemInstruction: "You are GodwithYou, a futuristic, helpful AI assistant. Keep responses concise and natural.",
      },
      callbacks: {
        onopen: () => {
          this.onStatusChange("Connected. Listening...");
          this.startAudioInput(stream, sessionPromise);
        },
        onmessage: (msg: LiveServerMessage) => this.handleMessage(msg),
        onclose: () => this.onStatusChange("Disconnected"),
        onerror: (e) => {
            console.error(e);
            this.onStatusChange("Error: Signal Lost");
        }
      }
    });
    
    this.session = sessionPromise;
  }

  startAudioInput(stream: MediaStream, sessionPromise: Promise<any>) {
    if (!this.inputContext) return;
    
    this.inputSource = this.inputContext.createMediaStreamSource(stream);
    this.processor = this.inputContext.createScriptProcessor(4096, 1, 1);
    
    this.processor.onaudioprocess = (e) => {
      const inputData = e.inputBuffer.getChannelData(0);
      const pcmData = this.floatTo16BitPCM(inputData);
      const base64 = this.arrayBufferToBase64(pcmData.buffer);
      
      sessionPromise.then(session => {
        session.sendRealtimeInput({
            media: {
                mimeType: 'audio/pcm;rate=16000',
                data: base64
            }
        });
      });
    };
    
    this.inputSource.connect(this.processor);
    this.processor.connect(this.inputContext.destination);
  }

  async handleMessage(msg: LiveServerMessage) {
    // Audio Output
    const data = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
    if (data) {
        await this.playAudio(data);
    }
    
    // Interruption handling
    if (msg.serverContent?.interrupted) {
        this.stopAudioOutput();
    }
  }

  async playAudio(base64: string) {
      if (!this.outputContext) return;
      
      const float32 = this.base64ToFloat32(base64);
      const buffer = this.outputContext.createBuffer(1, float32.length, 24000);
      buffer.getChannelData(0).set(float32);
      
      const source = this.outputContext.createBufferSource();
      source.buffer = buffer;
      source.connect(this.outputContext.destination);
      
      const now = this.outputContext.currentTime;
      const start = Math.max(this.nextStartTime, now);
      source.start(start);
      this.nextStartTime = start + buffer.duration;
      
      this.sources.add(source);
      source.onended = () => this.sources.delete(source);
  }

  stopAudioOutput() {
      this.sources.forEach(s => s.stop());
      this.sources.clear();
      this.nextStartTime = this.outputContext?.currentTime || 0;
  }

  disconnect() {
      if (this.session) {
          this.session.then((s: any) => s.close());
      }
      this.inputSource?.disconnect();
      this.processor?.disconnect();
      this.inputContext?.close();
      this.outputContext?.close();
  }

  // Helpers
  floatTo16BitPCM(float32: Float32Array) {
      const int16 = new Int16Array(float32.length);
      for (let i = 0; i < float32.length; i++) {
          let s = Math.max(-1, Math.min(1, float32[i]));
          int16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
      }
      return int16;
  }

  arrayBufferToBase64(buffer: ArrayBuffer) {
      let binary = '';
      const bytes = new Uint8Array(buffer);
      const len = bytes.byteLength;
      for (let i = 0; i < len; i++) {
          binary += String.fromCharCode(bytes[i]);
      }
      return btoa(binary);
  }

  base64ToFloat32(base64: string) {
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
      }
      const int16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(int16.length);
      for (let i = 0; i < int16.length; i++) {
          float32[i] = int16[i] / 32768.0;
      }
      return float32;
  }
}
