
import { User, TimelineEvent, DecisionLog, Note, EmotionLog, Project, KnowledgeItem, ChatMessage, Strike, StrikeParticipation } from '../types';

// Constants
const DB_PREFIX = 'gwy_';
const GLOBAL_KEYS = {
  USERS_DIR: 'gwy_global_users', // Directory of all users (simulated DB table)
  STRIKES: 'gwy_global_strikes', // Public strikes
  SESSION: 'gwy_active_session', // Current User ID
};

// --- DATA ISOLATION HELPERS ---

const getActiveUserId = (): string | null => {
  return localStorage.getItem(GLOBAL_KEYS.SESSION);
};

// Generates a user-specific key: gwy_notes_user123
const getKey = (baseKey: string, forceGlobal: boolean = false): string => {
  if (forceGlobal) return baseKey;
  const uid = getActiveUserId();
  if (!uid) throw new Error("Access Denied: No active session.");
  return `${DB_PREFIX}${baseKey}_${uid}`;
};

// Generic Get/Set
const get = <T>(baseKey: string, forceGlobal: boolean = false): T[] => {
  try {
    const key = getKey(baseKey, forceGlobal);
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
};

const set = <T>(baseKey: string, data: T[], forceGlobal: boolean = false) => {
  const key = getKey(baseKey, forceGlobal);
  localStorage.setItem(key, JSON.stringify(data));
};

// --- AUTHENTICATION ---

export const getAllUsers = (): User[] => {
  const data = localStorage.getItem(GLOBAL_KEYS.USERS_DIR);
  return data ? JSON.parse(data) : [];
};

export const loginUser = (email: string, password: string): User | null => {
  const users = getAllUsers();
  const user = users.find(u => u.email === email && u.password === password);
  if (user) {
    localStorage.setItem(GLOBAL_KEYS.SESSION, user.id);
    return user;
  }
  return null;
};

export const registerUser = (user: User): boolean => {
  const users = getAllUsers();
  if (users.find(u => u.email === user.email)) return false; // Exists
  
  // Initialize default stats
  user.stats = {
    currentStreak: 0,
    longestStreak: 0,
    lastTaskDate: '',
    xp: 0,
    energyScore: 100
  };
  
  users.push(user);
  localStorage.setItem(GLOBAL_KEYS.USERS_DIR, JSON.stringify(users));
  localStorage.setItem(GLOBAL_KEYS.SESSION, user.id);
  
  // Seed initial private data
  seedDatabase(user.id);
  return true;
};

export const logout = () => {
  localStorage.removeItem(GLOBAL_KEYS.SESSION);
};

export const getUser = (): User | null => {
  const uid = getActiveUserId();
  if (!uid) return null;
  const users = getAllUsers();
  return users.find(u => u.id === uid) || null;
};

export const saveUser = (updatedUser: User) => {
  const users = getAllUsers();
  const idx = users.findIndex(u => u.id === updatedUser.id);
  if (idx >= 0) {
    users[idx] = updatedUser;
    localStorage.setItem(GLOBAL_KEYS.USERS_DIR, JSON.stringify(users));
  }
};

// --- STREAK ENGINE ---

export const checkStreak = () => {
  const user = getUser();
  if (!user) return;

  const today = new Date().toISOString().split('T')[0];
  if (user.stats.lastTaskDate === today) return; // Already counted today

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  if (user.stats.lastTaskDate === yesterdayStr) {
    // Continued streak
    user.stats.currentStreak += 1;
    if (user.stats.currentStreak > user.stats.longestStreak) {
      user.stats.longestStreak = user.stats.currentStreak;
    }
  } else {
    // Broken streak (or first day)
    user.stats.currentStreak = 1;
  }

  user.stats.lastTaskDate = today;
  user.stats.xp += 10;
  saveUser(user);
};

export const updateEnergyScore = (delta: number) => {
    const user = getUser();
    if (!user) return;
    let newScore = (user.stats.energyScore || 50) + delta;
    if (newScore > 100) newScore = 100;
    if (newScore < 0) newScore = 0;
    user.stats.energyScore = newScore;
    saveUser(user);
}

// --- PRIVATE DATA ACCESSORS ---

// Timeline
export const getTimeline = () => get<TimelineEvent>('timeline');
export const saveTimelineEvent = (event: TimelineEvent) => {
  const events = getTimeline();
  const existingIndex = events.findIndex(e => e.id === event.id);
  if (existingIndex >= 0) events[existingIndex] = event;
  else events.push(event);
  set('timeline', events);
};
export const deleteTimelineEvent = (id: string) => {
    const list = getTimeline().filter(e => e.id !== id);
    set('timeline', list);
};

// Decisions
export const getDecisions = () => get<DecisionLog>('decisions');
export const addDecision = (decision: DecisionLog) => {
  const list = getDecisions();
  list.unshift(decision);
  set('decisions', list);
};
export const deleteDecision = (id: string) => {
    const list = getDecisions().filter(d => d.id !== id);
    set('decisions', list);
};

// Notes
export const getNotes = () => get<Note>('notes');
export const saveNote = (note: Note) => {
  const list = getNotes();
  const idx = list.findIndex(n => n.id === note.id);
  if (idx >= 0) list[idx] = note;
  else list.unshift(note);
  set('notes', list);
};
export const deleteNote = (id: string) => {
  const list = getNotes().filter(n => n.id !== id);
  set('notes', list);
};

// Emotions
export const getEmotions = () => get<EmotionLog>('emotions');
export const addEmotion = (log: EmotionLog) => {
  const list = getEmotions();
  list.unshift(log);
  set('emotions', list);
};
export const deleteEmotion = (id: string) => {
    const list = getEmotions().filter(e => e.id !== id);
    set('emotions', list);
};

// Projects
export const getProjects = () => get<Project>('projects');
export const saveProject = (project: Project) => {
  const list = getProjects();
  const idx = list.findIndex(p => p.id === project.id);
  if (idx >= 0) list[idx] = project;
  else list.push(project);
  set('projects', list);
};
export const deleteProject = (id: string) => {
    const list = getProjects().filter(p => p.id !== id);
    set('projects', list);
};

// Knowledge
export const getKnowledge = () => get<KnowledgeItem>('knowledge');
export const addKnowledge = (item: KnowledgeItem) => {
  const list = getKnowledge();
  list.unshift(item);
  set('knowledge', list);
};

// Chat
export const getChatHistory = () => get<ChatMessage>('chat');
export const addChatMessage = (msg: ChatMessage) => {
  const list = getChatHistory();
  list.push(msg);
  set('chat', list);
};
export const deleteChatMessage = (id: string) => {
    const list = getChatHistory().filter(m => m.id !== id);
    set('chat', list);
};
export const clearChatHistory = () => {
    set('chat', []);
};

// --- STRIKES (GLOBAL & PARTICIPATION) ---

export const getStrikes = () => get<Strike>(GLOBAL_KEYS.STRIKES, true);
export const getStrikeById = (id: string) => getStrikes().find(s => s.id === id);

export const createStrike = (strike: Strike) => {
    const list = getStrikes();
    list.unshift(strike);
    set(GLOBAL_KEYS.STRIKES, list, true);
};

export const deleteStrike = (id: string) => {
    // Delete global reference
    const list = getStrikes().filter(s => s.id !== id);
    set(GLOBAL_KEYS.STRIKES, list, true);
    
    // Delete user participation
    const myStrikes = getMyStrikes().filter(s => s.strikeId !== id);
    set('strike_participation', myStrikes);
};

export const getMyStrikes = () => get<StrikeParticipation>('strike_participation');

export const updateStrikeParticipation = (participation: StrikeParticipation) => {
    const list = getMyStrikes();
    const idx = list.findIndex(p => p.id === participation.id);
    if(idx >= 0) {
        list[idx] = participation;
        set('strike_participation', list);
    }
}

export const joinStrike = (strikeId: string) => {
    const uid = getActiveUserId();
    if(!uid) return;
    
    // Check if already joined
    const myStrikes = getMyStrikes();
    if(myStrikes.find(s => s.strikeId === strikeId)) return;

    // Update Global Count
    const strikes = getStrikes();
    const strikeIdx = strikes.findIndex(s => s.id === strikeId);
    if(strikeIdx >= 0) {
        strikes[strikeIdx].participantsCount++;
        set(GLOBAL_KEYS.STRIKES, strikes, true);
    }

    // Add Private Participation
    const participation: StrikeParticipation = {
        id: crypto.randomUUID(),
        strikeId,
        userId: uid,
        startDate: new Date().toISOString(),
        currentDay: 1,
        completedDates: [],
        active: true
    };
    
    myStrikes.push(participation);
    set('strike_participation', myStrikes);
};

// --- CONTEXT AGGREGATION ---

export const getSystemContext = () => {
  const user = getUser();
  if (!user) return "System Offline";
  
  const emotions = getEmotions().slice(0, 5);
  const projects = getProjects().filter(p => p.status === 'active');
  const decisions = getDecisions().slice(0, 3);
  const timeline = getTimeline().slice(-3);

  return JSON.stringify({
    userName: user.name,
    userStats: user.stats,
    recentMoods: emotions.map(e => ({ mood: e.mood, note: e.note })),
    activeProjects: projects.map(p => ({ name: p.name, progress: p.progress })),
    recentDecisions: decisions.map(d => d.query),
    timelineContext: timeline.map(t => ({ title: t.title, type: t.type }))
  });
};

// --- SEEDING ---

export const seedDatabase = (userId: string) => {
    // We manually set keys here to bypass the "active user check" during registration if needed,
    // but typically we are logged in right after reg.
    // For simplicity, we assume the user is logged in or we use explicit keys.
    const key = (base: string) => `${DB_PREFIX}${base}_${userId}`;
    
    const initialProjects: Project[] = [{
        id: 'p1', name: 'Master AI Development', description: 'Become an expert in GenAI integration.', status: 'active', progress: 25, tasks: []
    }];
    
    const initialTimeline: TimelineEvent[] = [{
        id: 'birth', title: 'Origin', date: '1995-01-01', description: 'The beginning of the journey.', type: 'past', impact: 'neutral', category: 'Life'
    }];

    localStorage.setItem(key('projects'), JSON.stringify(initialProjects));
    localStorage.setItem(key('timeline'), JSON.stringify(initialTimeline));
};
