import React, { useContext, useState } from 'react';
import { AppContext } from '../App';
import * as DB from '../services/db';
import { Settings as SettingsIcon, Key, CheckCircle } from 'lucide-react';

export default function SettingsPage() {
  const { user, setUser } = useContext(AppContext);
  const [key, setKey] = useState(user?.apiKey || '');
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    if (!user) return;
    const updated = { ...user, apiKey: key };
    DB.saveUser(updated);
    setUser(updated);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="max-w-2xl mx-auto mt-10 animate-fade-in">
        <div className="flex items-center gap-4 mb-10">
            <div className="p-3 bg-primary/10 rounded-xl border border-primary/30">
                <SettingsIcon size={32} className="text-primary"/>
            </div>
            <div>
                <h1 className="text-3xl font-bold text-white font-sans">System Configuration</h1>
                <p className="text-slate-400 text-sm">Manage Core Parameters</p>
            </div>
        </div>
        
        <div className="glass-panel p-10 rounded-3xl border border-white/10 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-[100px] pointer-events-none"></div>

            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 relative z-10">
                <Key size={20} className="text-secondary"/> Neural Link (API)
            </h3>
            
            <p className="text-slate-400 text-sm mb-6 leading-relaxed relative z-10">
                To enable the <span className="text-white font-bold">Gemini Neural Engine</span>, please input your API Key. 
                This key allows GodwithYou to perform cognitive tasks, prediction, and creative generation.
            </p>
            
            <div className="space-y-4 relative z-10">
                <input 
                    type="password"
                    className="w-full holo-input p-4 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-primary/50 tracking-widest"
                    placeholder="Paste Gemini API Key here..."
                    value={key}
                    onChange={e => setKey(e.target.value)}
                />
                
                <button 
                    onClick={handleSave} 
                    className={`w-full font-bold py-4 rounded-xl transition-all uppercase tracking-widest text-sm flex justify-center items-center gap-2 ${
                        saved 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50' 
                        : 'neon-button text-white hover:scale-[1.01]'
                    }`}
                >
                    {saved ? <><CheckCircle size={18}/> Configuration Saved</> : 'Establish Connection'}
                </button>
                
                <div className="text-center mt-4">
                    <a href="https://aistudio.google.com/" target="_blank" className="text-xs text-primary hover:text-white transition-colors underline opacity-80">
                        Generate Free API Key via Google AI Studio
                    </a>
                </div>
            </div>
        </div>
    </div>
  );
}