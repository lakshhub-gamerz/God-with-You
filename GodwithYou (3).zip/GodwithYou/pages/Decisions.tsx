import React, { useState } from 'react';
import * as DB from '../services/db';
import { generateJSON } from '../services/ai';
import { BrainCircuit, Loader, Atom, ChevronRight, Scale, Clock, Zap } from 'lucide-react';

export default function Decisions() {
  const [query, setQuery] = useState('');
  const [options, setOptions] = useState(['', '']);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const addOption = () => setOptions([...options, '']);
  const updateOption = (idx: number, val: string) => {
    const newOpts = [...options];
    newOpts[idx] = val;
    setOptions(newOpts);
  };

  const analyze = async () => {
    if (!query || options.some(o => !o.trim())) return;
    setLoading(true);
    
    const prompt = `
      DECISION MATRIX REQUEST
      Query: "${query}"
      Paths: ${JSON.stringify(options)}
      
      Act as a Quantum Decision Engine. Simulate outcomes 5 years into the future.
      Return JSON:
      {
        "analysis": "Executive summary of the topological landscape of this choice.",
        "recommendation": "The optimal path.",
        "option_details": [
          { 
            "option": "Name", 
            "probability": 85 (0-100), 
            "emotional_impact": "Positive/Negative/Mixed", 
            "energy_cost": "High/Medium/Low",
            "time_cost": "Short/Long term investment",
            "long_term_consequences": "Brief forecast of the future.",
            "outcome": "Likely end state."
          }
        ]
      }
    `;

    const data = await generateJSON(prompt);
    setResult(data);
    
    DB.addDecision({
      id: crypto.randomUUID(),
      query,
      options,
      analysis: data.analysis || "Simulation Inconclusive",
      recommendation: data.recommendation,
      option_details: data.option_details,
      timestamp: Date.now(),
      tags: ['quantum-simulation']
    });
    
    setLoading(false);
  };

  return (
    <div className="max-w-5xl mx-auto animate-fade-in pb-20">
      <div className="flex items-center gap-6 mb-10">
         <div className="p-4 bg-primary/10 rounded-2xl border border-primary/30 shadow-[0_0_30px_rgba(139,92,246,0.2)]">
             <Atom className="text-primary w-10 h-10 animate-spin-slow" />
         </div>
         <div>
             <h1 className="text-4xl font-bold text-white font-sans tracking-tight">Quantum Decision Assistant</h1>
             <p className="text-slate-400 font-mono text-sm uppercase tracking-widest mt-1">Multiverse Outcome Simulation Engine</p>
         </div>
      </div>

      <div className="glass-panel p-10 rounded-3xl mb-12 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-[100px] pointer-events-none -translate-y-1/2 translate-x-1/2"></div>

        <div className="relative z-10">
            <label className="block text-xs font-bold text-primary mb-3 uppercase tracking-[0.2em]">Dilemma Parameters</label>
            <input 
              className="w-full holo-input p-6 rounded-2xl text-xl mb-10 focus:ring-0 font-light"
              placeholder="Enter the critical choice to be simulated..."
              value={query}
              onChange={e => setQuery(e.target.value)}
            />

            <label className="block text-xs font-bold text-secondary mb-3 uppercase tracking-[0.2em]">Bifurcation Paths</label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              {options.map((opt, idx) => (
                <div key={idx} className="flex gap-4 items-center group">
                    <span className="font-mono text-slate-600 text-xs w-6 group-hover:text-primary transition-colors">0{idx + 1}</span>
                    <input 
                      className="w-full holo-input p-4 rounded-xl transition-all focus:border-secondary"
                      placeholder={`Vector ${idx + 1}`}
                      value={opt}
                      onChange={e => updateOption(idx, e.target.value)}
                    />
                </div>
              ))}
              <button onClick={addOption} className="text-xs text-secondary hover:text-white font-bold uppercase tracking-widest flex items-center gap-2 px-10 py-4 border border-dashed border-secondary/30 rounded-xl hover:bg-secondary/10 transition-all">
                  <ChevronRight size={14}/> Add Vector
              </button>
            </div>

            <button 
              onClick={analyze} 
              disabled={loading}
              className="w-full py-6 neon-button rounded-2xl text-white font-bold text-lg tracking-[0.2em] uppercase hover:scale-[1.01] transition-all flex justify-center items-center gap-4 shadow-2xl"
            >
              {loading ? <Loader className="animate-spin" /> : <BrainCircuit />}
              {loading ? 'Simulating Timelines...' : 'Initiate Quantum Simulation'}
            </button>
        </div>
      </div>

      {result && (
        <div className="animate-fade-in space-y-8">
          <div className="p-8 bg-gradient-to-br from-emerald-900/40 to-slate-900/90 backdrop-blur-xl border border-emerald-500/30 rounded-3xl shadow-[0_0_50px_rgba(16,185,129,0.1)]">
            <h3 className="text-emerald-400 font-bold mb-4 text-xl flex items-center gap-3 font-sans">
                <span className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_10px_#34d399]"></span>
                Optimal Trajectory: {result.recommendation}
            </h3>
            <p className="text-slate-200 leading-relaxed text-lg font-light opacity-90">{result.analysis}</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {result.option_details?.map((opt: any, i: number) => (
              <div key={i} className="glass-card p-8 rounded-2xl relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-1 h-full bg-slate-800 group-hover:bg-slate-700 transition-colors">
                    <div className="w-full bg-gradient-to-b from-primary to-secondary transition-all duration-1000" style={{ height: `${opt.probability}%` }}></div>
                </div>
                
                <div className="pl-6 relative z-10">
                    <h4 className="font-bold text-white text-2xl mb-6 font-sans">{opt.option}</h4>
                    
                    <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                            <span className="block text-xs text-slate-500 uppercase tracking-wider mb-1">Probability</span>
                            <span className="text-white font-bold text-xl">{opt.probability}%</span>
                        </div>
                        <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                             <span className="block text-xs text-slate-500 uppercase tracking-wider mb-1">Impact</span>
                             <span className={`font-bold text-xl ${opt.emotional_impact.includes('Positive') ? 'text-emerald-400' : 'text-amber-400'}`}>{opt.emotional_impact}</span>
                        </div>
                    </div>

                    <div className="space-y-4 text-sm text-slate-400">
                        <div className="flex items-center gap-3">
                             <Zap size={16} className="text-secondary"/>
                             <span>Energy Cost: <strong className="text-slate-200">{opt.energy_cost}</strong></span>
                        </div>
                        <div className="flex items-center gap-3">
                             <Clock size={16} className="text-primary"/>
                             <span>Time Horizon: <strong className="text-slate-200">{opt.time_cost}</strong></span>
                        </div>
                        <div className="flex items-start gap-3 mt-4 pt-4 border-t border-white/5">
                             <Scale size={16} className="text-slate-500 mt-1"/>
                             <p className="leading-relaxed"><strong className="text-slate-300 block mb-1">Long-term:</strong> {opt.long_term_consequences}</p>
                        </div>
                    </div>
                </div>
                
                {/* Hover effect bg */}
                <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-secondary/5 rounded-full blur-3xl group-hover:bg-secondary/10 transition-colors"></div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
