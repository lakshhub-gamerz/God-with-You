import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppContext } from '../App';
import * as DB from '../services/db';
import { BrainCircuit } from 'lucide-react';
import { User } from '../types';

export default function Auth() {
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { setUser } = useContext(AppContext);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Construct valid User object with required 'stats'
    const newUser: User = {
      id: crypto.randomUUID(),
      name: isRegister ? name : 'Traveler',
      email,
      password,
      theme: 'dark',
      stats: {
        currentStreak: 0,
        longestStreak: 0,
        lastTaskDate: '',
        xp: 0,
        energyScore: 100
      }
    };
    
    if (isRegister) {
        // registerUser handles internal saving and seeding (db.seedDatabase(user.id))
        DB.registerUser(newUser);
        setUser(newUser);
    } else {
        // For login, try to find existing user
        const existing = DB.loginUser(email, password);
        if (existing) {
            setUser(existing);
        } else {
            // Fallback for simulated "Connect" if user doesn't exist: register them automatically
            DB.registerUser(newUser);
            setUser(newUser);
        }
    }
    
    navigate('/');
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-1/2 left-1/2 w-[800px] h-[800px] bg-primary/20 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2 animate-pulse-slow pointer-events-none"></div>

      <div className="w-full max-w-md p-10 glass-panel rounded-3xl shadow-2xl z-10 relative">
        <div className="flex justify-center mb-8">
          <div className="relative w-28 h-20 flex items-center justify-center bg-black/40 border-2 border-primary/50 rounded-lg shadow-[0_0_30px_rgba(139,92,246,0.4)] overflow-hidden">
              <div className="absolute inset-0 bg-primary/10 blur-md"></div>
              <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50"></div>
              <BrainCircuit size={40} className="text-primary relative z-10" />
          </div>
        </div>
        <h2 className="text-4xl font-bold text-center mb-2 text-white font-sans tracking-wide">
          {isRegister ? 'Initialize' : 'Connect'}
        </h2>
        <p className="text-center text-slate-400 mb-10 font-light">Access your extended intelligence.</p>

        <form onSubmit={handleSubmit} className="space-y-5">
          {isRegister && (
            <div>
              <label className="block text-xs font-bold text-primary mb-1 uppercase tracking-wider">Designation</label>
              <input 
                type="text" 
                required 
                className="w-full holo-input px-4 py-3 rounded-xl focus:outline-none"
                value={name}
                onChange={e => setName(e.target.value)}
              />
            </div>
          )}
          <div>
            <label className="block text-xs font-bold text-primary mb-1 uppercase tracking-wider">Identifier</label>
            <input 
              type="email" 
              required 
              className="w-full holo-input px-4 py-3 rounded-xl focus:outline-none"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-primary mb-1 uppercase tracking-wider">Access Code</label>
            <input 
              type="password" 
              required 
              className="w-full holo-input px-4 py-3 rounded-xl focus:outline-none"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
          </div>

          <button type="submit" className="w-full neon-button text-white font-bold py-4 rounded-xl transition-all hover:scale-[1.02] mt-4 uppercase tracking-widest text-sm shadow-lg">
            {isRegister ? 'Begin Sequence' : 'Establish Link'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button 
            onClick={() => setIsRegister(!isRegister)}
            className="text-sm text-slate-400 hover:text-white transition-colors"
          >
            {isRegister ? 'Already have an ID? Connect' : "Need Access? Initialize"}
          </button>
        </div>
      </div>
    </div>
  );
}