import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import * as DB from '../services/db';
import { generateJSON } from '../services/ai';
import { Project, Task } from '../types';
import { CheckCircle, Circle, Loader, Sparkles, Plus, Trash2, Calendar, Flag } from 'lucide-react';

export default function ProjectDetails() {
  const { id } = useParams();
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');

  useEffect(() => {
    const all = DB.getProjects();
    const p = all.find(x => x.id === id);
    if (p) setProject(p);
  }, [id]);

  const save = (p: Project) => {
    DB.saveProject(p);
    setProject({...p});
  };

  const generateRoadmap = async () => {
    if (!project) return;
    setLoading(true);
    const prompt = `
      Project: ${project.name}
      Description: ${project.description}
      Generate 5 key milestones/tasks to complete this project.
      Return JSON: { "tasks": [{ "title": "Task Title", "priority": "high/medium/low", "dueDate": "YYYY-MM-DD" }] }
    `;
    const data = await generateJSON(prompt);
    if (data.tasks) {
      const newTasks: Task[] = data.tasks.map((t: any) => ({
        id: crypto.randomUUID(),
        title: t.title,
        completed: false,
        priority: t.priority || 'medium',
        dueDate: t.dueDate || new Date().toISOString().split('T')[0]
      }));
      const updated = { ...project, tasks: [...project.tasks, ...newTasks] };
      save(updated);
    }
    setLoading(false);
  };

  const toggleTask = (taskId: string) => {
    if (!project) return;
    const updatedTasks = project.tasks.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t);
    // Fix division by zero protection
    const progress = updatedTasks.length > 0 
        ? Math.round((updatedTasks.filter(t => t.completed).length / updatedTasks.length) * 100)
        : 0;
    save({ ...project, tasks: updatedTasks, progress });
  };

  const addTask = () => {
      if(!newTaskTitle || !project) return;
      const t: Task = {
          id: crypto.randomUUID(),
          title: newTaskTitle,
          completed: false,
          priority: 'medium',
          dueDate: new Date().toISOString().split('T')[0]
      };
      const updatedTasks = [...project.tasks, t];
      // Fix division by zero protection
      const progress = updatedTasks.length > 0 
          ? Math.round((updatedTasks.filter(x => x.completed).length / updatedTasks.length) * 100)
          : 0;
      save({...project, tasks: updatedTasks, progress});
      setNewTaskTitle('');
  };

  const deleteTask = (taskId: string) => {
      if(!project) return;
      const updatedTasks = project.tasks.filter(t => t.id !== taskId);
      // Fix division by zero protection
      const progress = updatedTasks.length > 0 
          ? Math.round((updatedTasks.filter(x => x.completed).length / updatedTasks.length) * 100) 
          : 0;
      save({...project, tasks: updatedTasks, progress});
  };

  if (!project) return <div>Project not found</div>;

  return (
    <div className="max-w-4xl mx-auto animate-fade-in pb-20">
      <div className="mb-10 p-6 glass-panel rounded-3xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-[80px]"></div>
        <input 
            className="text-4xl font-bold bg-transparent text-white focus:outline-none w-full mb-4 font-sans tracking-tight relative z-10"
            value={project.name}
            onChange={e => save({...project, name: e.target.value})}
        />
        <textarea 
            className="w-full bg-transparent text-slate-300 resize-none focus:outline-none text-lg font-light relative z-10"
            value={project.description}
            onChange={e => save({...project, description: e.target.value})}
            rows={2}
        />
      </div>

      <div className="glass-panel p-8 rounded-2xl border border-white/5 mb-8">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-xl font-bold text-white uppercase tracking-widest flex items-center gap-3">
              <span className="w-1 h-6 bg-secondary rounded-full"></span>
              Roadmap
          </h2>
          <button onClick={generateRoadmap} disabled={loading} className="text-primary hover:text-white flex items-center gap-2 text-sm font-bold border border-primary/30 px-5 py-2 rounded-full hover:bg-primary/20 transition-all shadow-[0_0_15px_rgba(139,92,246,0.2)]">
            {loading ? <Loader className="animate-spin" size={16} /> : <Sparkles size={16} />} 
            AI Auto-Plan
          </button>
        </div>

        <div className="space-y-4">
          {project.tasks.map(task => (
            <div key={task.id} className="flex items-center gap-4 p-5 bg-black/20 rounded-xl hover:bg-white/5 transition-colors border border-white/5 hover:border-white/10 group animate-slide-up">
              <button onClick={() => toggleTask(task.id)} className={`transition-all ${task.completed ? 'text-emerald-400' : 'text-slate-600 hover:text-slate-400'}`}>
                {task.completed ? <CheckCircle size={24} /> : <Circle size={24} />}
              </button>
              
              <div className="flex-1">
                  <span className={`block text-lg font-light ${task.completed ? 'text-slate-500 line-through' : 'text-slate-100'}`}>
                    {task.title}
                  </span>
                  <div className="flex gap-4 mt-1">
                      <span className="text-xs text-slate-500 flex items-center gap-1">
                          <Flag size={10} className={task.priority === 'high' ? 'text-red-400' : 'text-slate-600'}/> {task.priority}
                      </span>
                      {task.dueDate && (
                          <span className="text-xs text-slate-500 flex items-center gap-1">
                              <Calendar size={10}/> {task.dueDate}
                          </span>
                      )}
                  </div>
              </div>

              <button onClick={() => deleteTask(task.id)} className="text-slate-700 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all p-2"><Trash2 size={18}/></button>
            </div>
          ))}
          
          <div className="flex items-center gap-3 p-4 mt-4 bg-white/5 rounded-xl border border-dashed border-white/10">
              <Plus size={20} className="text-slate-500"/>
              <input 
                className="bg-transparent text-white focus:outline-none flex-1 placeholder-slate-600"
                placeholder="Add new directive..."
                value={newTaskTitle}
                onChange={e => setNewTaskTitle(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addTask()}
              />
              <button onClick={addTask} className="text-sm text-primary font-bold uppercase tracking-wider">ADD</button>
          </div>
        </div>
      </div>
    </div>
  );
}