import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import * as DB from '../services/db';
import { Strike } from '../types';
import { Flame, Users, Plus, Target, Trophy, Lock, ArrowRight, Trash2 } from 'lucide-react';

export default function Strikes() {
  const [strikes, setStrikes] = useState<Strike[]>([]);
  const [myStrikes, setMyStrikes] = useState<string[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [newStrike, setNewStrike] = useState<Partial<Strike>>({ type: 'focus', difficulty: 'medium' });
  const navigate = useNavigate();

  useEffect(() => {
    setStrikes(DB.getStrikes());
    setMyStrikes(DB.getMyStrikes().map(s => s.strikeId));
  }, []);

  const handleJoin = (id: string) => {
    DB.joinStrike(id);
    setMyStrikes([...myStrikes, id]);
    // Refresh list to update count
    setStrikes(DB.getStrikes());
    navigate(`/strikes/${id}`);
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      e.preventDefault();
      if(window.confirm('Delete this Strike Protocol permanently?')) {
          DB.deleteStrike(id);
          setStrikes(prev => prev.filter(s => s.id !== id));
      }
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStrike.title || !newStrike.dailyGoal) return;
    
    const strike: Strike = {
        id: crypto.randomUUID(),
        creatorId: 'anon',
        title: newStrike.title,
        description: newStrike.description || '',
        type: newStrike.type as any,
        difficulty: newStrike.difficulty as any,
        durationDays: newStrike.durationDays || 7,
        dailyGoal: newStrike.dailyGoal,
        participantsCount: 1,
        tags: [],
        createdAt: Date.now()
    };
    
    DB.createStrike(strike);
    DB.joinStrike(strike.id); // Creator joins auto
    setStrikes([strike, ...strikes]);
    setMyStrikes([...myStrikes, strike.id]);
    setShowCreate(false);
    navigate(`/strikes/${strike.id}`);
  };

  return (
    <div className="animate-fade-in pb-20">
      <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
        <div>
           <div className="flex items-center gap-3 mb-2">
               <div className="p-2 bg-orange-500/10 rounded-lg border border-orange-500/30">
                   <Flame className="text-orange-500" size={24}/>
               </div>
               <h1 className="text-4xl font-bold text-white tracking-tight">Strike Protocol</h1>
           </div>
           <p className="text-slate-400 font-mono text-sm max-w-xl">Anonymous, collective energy directives. Join forces in the void.</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="neon-button px-6 py-3 text-white rounded-xl flex items-center gap-2 font-bold uppercase tracking-wider text-sm hover:scale-105 transition-transform shadow-lg">
           <Plus size={18}/> Initiate Strike
        </button>
      </div>

      {showCreate && (
          <div className="glass-panel p-8 rounded-3xl mb-12 border border-white/10 relative overflow-hidden animate-slide-up">
              <div className="relative z-10">
                  <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                      <Target className="text-primary"/> Define Parameters
                  </h3>
                  <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="col-span-2">
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Strike Title</label>
                          <input className="w-full holo-input p-3 rounded-xl" placeholder="e.g. 7-Day Deep Work" value={newStrike.title || ''} onChange={e => setNewStrike({...newStrike, title: e.target.value})} required/>
                      </div>
                      <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Duration (Days)</label>
                          <input type="number" className="w-full holo-input p-3 rounded-xl" value={newStrike.durationDays || 7} onChange={e => setNewStrike({...newStrike, durationDays: parseInt(e.target.value)})}/>
                      </div>
                      <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Difficulty</label>
                          <select className="w-full holo-input p-3 rounded-xl" value={newStrike.difficulty} onChange={e => setNewStrike({...newStrike, difficulty: e.target.value as any})}>
                              <option value="easy">Easy</option>
                              <option value="medium">Medium</option>
                              <option value="hard">Hard</option>
                              <option value="god-mode">God Mode</option>
                          </select>
                      </div>
                      <div className="col-span-2">
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Daily Goal Directive</label>
                          <input className="w-full holo-input p-3 rounded-xl" placeholder="e.g. Read 30 pages" value={newStrike.dailyGoal || ''} onChange={e => setNewStrike({...newStrike, dailyGoal: e.target.value})} required/>
                      </div>
                      <div className="col-span-2 flex gap-4 pt-4">
                          <button type="button" onClick={() => setShowCreate(false)} className="px-6 py-3 rounded-xl text-slate-400 hover:bg-white/5">Cancel</button>
                          <button type="submit" className="flex-1 bg-primary text-white font-bold rounded-xl hover:bg-primary/80">Launch Strike</button>
                      </div>
                  </form>
              </div>
          </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {strikes.map(strike => {
              const joined = myStrikes.includes(strike.id);
              return (
                  <div key={strike.id} className={`glass-card p-6 rounded-2xl border flex flex-col relative group overflow-hidden ${joined ? 'border-primary/40 bg-primary/5' : 'border-white/5'}`}>
                      {/* Glow effect */}
                      <div className="absolute -right-10 -top-10 w-32 h-32 bg-secondary/10 rounded-full blur-3xl group-hover:bg-secondary/20 transition-colors pointer-events-none"></div>
                      
                      <div className="flex justify-between items-start mb-4 relative z-10">
                          <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded border ${
                              strike.difficulty === 'god-mode' ? 'border-red-500 text-red-400 bg-red-500/10' :
                              strike.difficulty === 'hard' ? 'border-orange-500 text-orange-400 bg-orange-500/10' :
                              'border-emerald-500 text-emerald-400 bg-emerald-500/10'
                          }`}>
                              {strike.difficulty}
                          </span>
                          <div className="flex items-center gap-2">
                              <span className="flex items-center gap-1 text-xs text-slate-500">
                                  <Users size={12}/> {strike.participantsCount}
                              </span>
                              {joined && (
                                  <button 
                                    onClick={(e) => handleDelete(e, strike.id)} 
                                    className="p-2 -mr-2 text-slate-600 hover:text-red-400 z-50 relative hover:bg-white/5 rounded-full transition-colors"
                                    title="Delete Strike"
                                  >
                                      <Trash2 size={16}/>
                                  </button>
                              )}
                          </div>
                      </div>

                      <h3 className="text-xl font-bold text-white mb-2 font-sans">{strike.title}</h3>
                      <p className="text-slate-400 text-sm mb-6 flex-1">{strike.dailyGoal}</p>

                      <div className="flex items-center justify-between border-t border-white/5 pt-4 mt-auto relative z-10">
                          <div className="text-xs text-slate-500 font-mono">
                              {strike.durationDays} DAYS
                          </div>
                          {joined ? (
                              <button onClick={() => navigate(`/strikes/${strike.id}`)} className="flex items-center gap-2 text-primary font-bold text-xs uppercase tracking-wider hover:text-white transition-colors">
                                  <Lock size={12}/> Access Protocol <ArrowRight size={12}/>
                              </button>
                          ) : (
                              <button onClick={() => handleJoin(strike.id)} className="text-xs font-bold text-white bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg transition-colors">
                                  Join Strike
                              </button>
                          )}
                      </div>
                  </div>
              );
          })}
          
          {strikes.length === 0 && (
              <div className="col-span-full text-center py-20 text-slate-500">
                  <Trophy size={48} className="mx-auto mb-4 opacity-20"/>
                  <p>No active strikes in the sector. Initiate one.</p>
              </div>
          )}
      </div>
    </div>
  );
}