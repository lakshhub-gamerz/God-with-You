import React, { useState } from 'react';
import { Send, MessageSquare } from 'lucide-react';

export default function Feedback() {
  const [text, setText] = useState('');
  const [sent, setSent] = useState(false);

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setText('');
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <div className="max-w-2xl mx-auto mt-10 animate-fade-in">
        <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-white mb-2 font-sans">System Feedback</h1>
            <p className="text-slate-400">Transmit logs to the developer core.</p>
        </div>

        <div className="glass-panel p-10 rounded-3xl border border-white/10 relative overflow-hidden">
             <div className="absolute -left-10 -bottom-10 w-40 h-40 bg-secondary/10 rounded-full blur-2xl"></div>

            <form onSubmit={send} className="relative z-10">
                <label className="block text-xs font-bold text-primary mb-4 uppercase tracking-widest flex items-center gap-2">
                    <MessageSquare size={14}/> Transmission Data
                </label>
                <textarea 
                    required
                    className="w-full holo-input p-6 rounded-2xl text-white focus:outline-none resize-none h-48 mb-6 font-light"
                    placeholder="Describe bugs, feature requests, or anomalies..."
                    value={text}
                    onChange={e => setText(e.target.value)}
                />
                <button className={`w-full font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-sm ${sent ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50' : 'neon-button text-white hover:scale-[1.01]'}`}>
                    {sent ? 'Transmission Received' : <><Send size={18}/> Submit Feedback</>}
                </button>
            </form>
        </div>
    </div>
  );
}