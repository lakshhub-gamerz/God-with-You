import React, { useState, useEffect } from 'react';
import * as DB from '../services/db';
import { EmotionLog } from '../types';
import { generateContent, generateJSON } from '../services/ai';
import { Wind, Activity, HeartPulse, Sparkles, Brain, Zap, ShieldAlert, Trash2 } from 'lucide-react';

export default function Emotions() {
  const [logs, setLogs] = useState<EmotionLog[]>([]);
  const [breathing, setBreathing] = useState(false);
  const [selectedMood, setSelectedMood] = useState<number | null>(null);
  const [cognitiveLoad, setCognitiveLoad] = useState(50);
  const [note, setNote] = useState('');
  const [recovery, setRecovery] = useState<string | null>(null);

  useEffect(() => {
    setLogs(DB.getEmotions());
  }, []);

  const logEmotion = async () => {
    if (selectedMood === null) return;
    
    // NeuroSync Logic: High cognitive load triggers recovery suggestion
    let recoveryPlan = "";
    if (cognitiveLoad > 80) {
        recoveryPlan = "Warning: Neuro-overload detected. Initiating dopamine detox protocol. Recommend: 15m silence.";
    }

    const newLog: EmotionLog = {
      id: crypto.randomUUID(),
      mood: selectedMood,
      energy: 100 - cognitiveLoad, 
      labels: [],
      note,
      timestamp: Date.now(),
      recoveryMode: recoveryPlan
    };
    
    // AI Analysis (LUMA)
    if (note) {
         const analysis = await generateContent(`Act as LUMA (Emotional AI). Analyze: "${note}". Mood: ${selectedMood}/10. Load: ${cognitiveLoad}%. Max 1 sentence.`);
         newLog.aiAnalysis = analysis;
    }

    DB.addEmotion(newLog);
    setLogs([newLog, ...logs]);
    if (recoveryPlan) setRecovery(recoveryPlan);
    
    setSelectedMood(null);
    setNote('');
  };

  const handleDelete = (id: string) => {
      if(!confirm("Delete this emotional record?")) return;
      DB.deleteEmotion(id);
      setLogs(logs.filter(l => l.id !== id));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-full pb-12 animate-fade-in">
      {/* Logger Column */}
      <div className="lg:col-span-7 space-y-8">
        <div className="flex items-center gap-4 mb-8">
             <div className="p-3 bg-pink-500/10 rounded-xl border border-pink-500/30">
                 <HeartPulse className="text-pink-400 animate-pulse" size={32}/>
             </div>
             <div>
                 <h1 className="text-3xl font-bold text-white font-sans">LifeSync (Luma)</h1>
                 <p className="text-slate-400 text-xs uppercase tracking-widest">Emotional & Cognitive Resonance</p>
             </div>
        </div>
        
        <div className="glass-panel p-8 rounded-3xl relative overflow-hidden border-t border-pink-500/20">
          <div className="absolute top-0 right-0 w-64 h-64 bg-pink-500/5 rounded-full blur-[80px]"></div>
          
          <div className="relative z-10 space-y-8">
              {/* Mood Slider */}
              <div>
                  <div className="flex justify-between mb-4">
                    <label className="text-xs font-bold text-slate-300 uppercase tracking-widest">Emotional Valence</label>
                    <span className="text-pink-400 font-mono">{selectedMood ? selectedMood : '-'}/10</span>
                  </div>
                  <div className="flex justify-between gap-1">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => (
                    <button 
                        key={n}
                        onClick={() => setSelectedMood(n)}
                        className={`flex-1 h-10 rounded-md transition-all font-mono text-xs border border-transparent ${
                            selectedMood === n 
                            ? 'bg-pink-500 text-white shadow-[0_0_15px_#ec4899] scale-110' 
                            : 'bg-white/5 hover:bg-white/10 text-slate-500'
                        }`}
                    >
                        {n}
                    </button>
                    ))}
                  </div>
              </div>

              {/* Cognitive Load Slider (NeuroSync) */}
              <div>
                  <div className="flex justify-between mb-4">
                    <label className="text-xs font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
                        <Brain size={14} className="text-cyan-400"/> NeuroSync: Cognitive Load
                    </label>
                    <span className={`font-mono ${cognitiveLoad > 80 ? 'text-red-400 animate-pulse' : 'text-cyan-400'}`}>{cognitiveLoad}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" max="100" 
                    value={cognitiveLoad} 
                    onChange={e => setCognitiveLoad(parseInt(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                  <div className="flex justify-between text-[10px] text-slate-600 uppercase mt-2">
                      <span>Clear Mind</span>
                      <span>Flow State</span>
                      <span>Overload</span>
                  </div>
              </div>

              <textarea 
                className="w-full holo-input p-5 rounded-xl text-white mb-6 focus:outline-none h-24 resize-none text-sm font-light"
                placeholder="Data dump your feelings..."
                value={note}
                onChange={e => setNote(e.target.value)}
              />

              <button 
                onClick={logEmotion}
                disabled={selectedMood === null}
                className="w-full py-4 neon-button text-white font-bold rounded-xl transition-all hover:scale-[1.02] disabled:opacity-50 disabled:grayscale uppercase tracking-[0.2em] text-sm"
              >
                Sync State
              </button>
          </div>
        </div>

        {/* Recovery Mode Alert */}
        {recovery && (
            <div className="bg-red-500/10 border border-red-500/30 p-6 rounded-2xl flex items-start gap-4 animate-pulse">
                <ShieldAlert className="text-red-400 shrink-0" size={24} />
                <div>
                    <h3 className="text-red-400 font-bold uppercase tracking-widest text-sm mb-1">Recovery Mode Activated</h3>
                    <p className="text-slate-300 text-sm font-light">{recovery}</p>
                </div>
            </div>
        )}
      </div>

      {/* History & Insights Column */}
      <div className="lg:col-span-5 space-y-6">
          <div className="glass-panel rounded-2xl p-6 overflow-y-auto h-[600px] custom-scrollbar">
            <h3 className="text-slate-400 font-bold uppercase tracking-wider mb-6 flex items-center gap-2 text-xs">
                <Activity size={14}/> Resonance Log
            </h3>
            <div className="space-y-4">
            {logs.map(log => (
                <div key={log.id} className="glass-card p-5 rounded-xl border-l-2 border-l-white/10 hover:border-l-pink-400 transition-all group relative">
                    <button 
                      onClick={() => handleDelete(log.id)} 
                      className="absolute top-4 right-4 text-slate-600 hover:text-red-400 opacity-60 hover:opacity-100 transition-all"
                      title="Delete Entry"
                    >
                        <Trash2 size={14}/>
                    </button>
                    <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-3">
                            <span className={`text-lg font-bold ${log.mood > 5 ? 'text-pink-400' : 'text-slate-400'}`}>{log.mood}</span>
                            <div className="h-4 w-[1px] bg-white/10"></div>
                            <div className="flex flex-col">
                                <span className="text-[10px] text-slate-500 font-mono uppercase">Load: {100 - log.energy}%</span>
                                <span className="text-[10px] text-slate-500 font-mono">{new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                            </div>
                        </div>
                    </div>
                    {log.note && <p className="text-slate-200 text-sm mb-3 font-light leading-relaxed">"{log.note}"</p>}
                    {log.aiAnalysis && (
                        <div className="bg-pink-500/5 border border-pink-500/10 p-3 rounded-lg text-xs text-pink-200 flex gap-2">
                            <Sparkles size={12} className="shrink-0 mt-0.5 text-pink-500"/>
                            {log.aiAnalysis}
                        </div>
                    )}
                </div>
            ))}
            </div>
        </div>
      </div>
    </div>
  );
}