import React from 'react';
import { HelpCircle, GitFork, BrainCircuit, ShieldCheck } from 'lucide-react';

export default function Help() {
  return (
    <div className="max-w-4xl mx-auto animate-fade-in pb-20">
        <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-4 font-sans tracking-tight">Knowledge Base</h1>
            <p className="text-slate-400">Operational Guidelines & System Architecture</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="glass-panel p-8 rounded-2xl border-t border-primary/20 hover:border-primary/50 transition-colors group">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6 text-primary group-hover:scale-110 transition-transform">
                    <BrainCircuit size={28}/>
                </div>
                <h3 className="font-bold text-white text-xl mb-3 font-sans">What is GodwithYou?</h3>
                <p className="text-slate-400 leading-relaxed font-light text-sm">
                    An experimental "Human Operating System" designed to extend cognitive and emotional capabilities through AI integration. It tracks bio-states, predicts timelines, and organizes your neural output.
                </p>
            </div>

            <div className="glass-panel p-8 rounded-2xl border-t border-secondary/20 hover:border-secondary/50 transition-colors group">
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center mb-6 text-secondary group-hover:scale-110 transition-transform">
                    <GitFork size={28}/>
                </div>
                <h3 className="font-bold text-white text-xl mb-3 font-sans">The Timeline Engine</h3>
                <p className="text-slate-400 leading-relaxed font-light text-sm">
                    The Timeline allows you to log past events to create a trajectory. The AI uses this historical data to extrapolate probability waves and predict future milestones (purple nodes).
                </p>
            </div>
             
             <div className="glass-panel p-8 rounded-2xl border-t border-emerald-500/20 hover:border-emerald-500/50 transition-colors group md:col-span-2">
                <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center mb-6 text-emerald-400 group-hover:scale-110 transition-transform">
                    <ShieldCheck size={28}/>
                </div>
                <h3 className="font-bold text-white text-xl mb-3 font-sans">Data Privacy & Security</h3>
                <p className="text-slate-400 leading-relaxed font-light text-sm">
                    All personal data (notes, emotions, timeline) is stored locally in your browser's encrypted LocalStorage. We do not maintain a central database. 
                    The API Key is used strictly for direct client-to-Google communication to power the intelligence layer.
                </p>
            </div>
        </div>
    </div>
  );
}