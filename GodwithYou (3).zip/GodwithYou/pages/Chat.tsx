import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import * as DB from '../services/db';
import { generateContent, generateThinkingResponse, generateSpeech, playAudioData, LiveSession, generateGroundedContent, generateImage, analyzeImage, transcribeAudio } from '../services/ai';
import { ChatMessage } from '../types';
import { Send, Bot, User as UserIcon, Sparkles, Trash2, Zap, Brain, Volume2, Loader, Mic, X, Image as ImageIcon, Globe, Paperclip, StopCircle, History as HistoryIcon } from 'lucide-react';

type ModelMode = 'lite' | 'standard' | 'thinking';
type ImageSize = '1K' | '2K' | '4K';

export default function Chat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [playingAudio, setPlayingAudio] = useState<string | null>(null);
  
  // Settings State
  const [mode, setMode] = useState<ModelMode>('standard');
  const [grounding, setGrounding] = useState(false);
  const [imgGenMode, setImgGenMode] = useState(false);
  const [imgSize, setImgSize] = useState<ImageSize>('1K');
  const [attachment, setAttachment] = useState<{data: string, mimeType: string} | null>(null);

  // Audio Recording State
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Live Session State
  const [isLive, setIsLive] = useState(false);
  const [liveStatus, setLiveStatus] = useState("Disconnected");
  const liveSession = useRef<LiveSession | null>(null);

  useEffect(() => {
    setMessages(DB.getChatHistory());
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onloadend = () => {
          const base64 = reader.result as string;
          // Strip prefix data:image/png;base64,
          const base64Data = base64.split(',')[1];
          setAttachment({ data: base64Data, mimeType: file.type });
      };
      reader.readAsDataURL(file);
  };

  const startRecording = async () => {
      try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          const mediaRecorder = new MediaRecorder(stream);
          const chunks: Blob[] = [];

          mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
          mediaRecorder.onstop = async () => {
              const blob = new Blob(chunks, { type: 'audio/webm' }); // Browsers often record webm/ogg
              // Convert to base64
              const reader = new FileReader();
              reader.onloadend = async () => {
                   const base64 = reader.result as string;
                   const base64Data = base64.split(',')[1];
                   setLoading(true);
                   // Send for transcription
                   // Note: Audio file transcription uses gemini-2.5-flash
                   const text = await transcribeAudio(base64Data, 'audio/webm');
                   setInput(prev => prev + " " + text);
                   setLoading(false);
              };
              reader.readAsDataURL(blob);
              stream.getTracks().forEach(t => t.stop());
          };

          mediaRecorderRef.current = mediaRecorder;
          mediaRecorder.start();
          setIsRecording(true);
      } catch (e) {
          console.error("Mic access denied");
      }
  };

  const stopRecording = () => {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
  };

  const sendMessage = async () => {
    if (!input.trim() && !attachment && !imgGenMode) return;
    
    // Construct User Message
    const userMsg: ChatMessage = { id: crypto.randomUUID(), role: 'user', content: input, timestamp: Date.now() };
    
    // Add image preview to user message for display if exists
    // (Note: storing base64 in DB is heavy, ideally just temp display or link, but for local app it's ok)
    if(attachment) {
        userMsg.content = `[Image Attached] ${input}`;
    }
    if(imgGenMode) {
        userMsg.content = `[Generate Image: ${imgSize}] ${input}`;
    }

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    DB.addChatMessage(userMsg);
    
    const promptText = input;
    setInput('');
    setAttachment(null);
    setLoading(true);

    let responseText = "";

    try {
        if (imgGenMode) {
            // IMAGE GENERATION
            const imgData = await generateImage(promptText, imgSize);
            if (imgData) {
                responseText = `![Generated Image](${imgData})`;
            } else {
                responseText = "Image generation failed.";
            }
        } else if (attachment) {
            // IMAGE ANALYSIS
            responseText = await analyzeImage(attachment.data, attachment.mimeType, promptText || "Describe this image.");
        } else if (grounding) {
            // SEARCH GROUNDING
            responseText = await generateGroundedContent(promptText);
        } else if (mode === 'lite') {
            const last3 = messages.slice(-3).map(m => `${m.role}: ${m.content}`).join('\n');
            const prompt = `Context:\n${last3}\nUser: ${promptText}\nRespond as 'GodwithYou'. Be extremely concise and fast.`;
            responseText = await generateContent(prompt, 'gemini-2.5-flash-lite');
        } else if (mode === 'thinking') {
             const last3 = messages.slice(-3).map(m => `${m.role}: ${m.content}`).join('\n');
             const prompt = `Context:\n${last3}\nUser: ${promptText}\nRespond as 'GodwithYou'. Think deeply about the user's request.`;
            responseText = await generateThinkingResponse(prompt);
        } else {
             const last3 = messages.slice(-3).map(m => `${m.role}: ${m.content}`).join('\n');
             const prompt = `Context:\n${last3}\nUser: ${promptText}\nRespond as 'GodwithYou'. Helpful and intelligent.`;
            responseText = await generateContent(prompt, 'gemini-2.5-flash');
        }
    } catch (e) {
        responseText = "Neural connection unstable.";
    }
    
    const aiMsg: ChatMessage = { id: crypto.randomUUID(), role: 'model', content: responseText, timestamp: Date.now() };
    setMessages(prev => [...prev, aiMsg]);
    DB.addChatMessage(aiMsg);
    setLoading(false);
  };

  const speakMessage = async (text: string, id: string) => {
      // Strip markdown images before speaking
      const cleanText = text.replace(/!\[.*?\]\(.*?\)/g, '');
      setPlayingAudio(id);
      const audioData = await generateSpeech(cleanText);
      if (audioData) {
          await playAudioData(audioData);
      }
      setPlayingAudio(null);
  };

  const clear = () => {
      if(confirm("Clear local chat memory?")) {
          DB.clearChatHistory();
          setMessages([]);
      }
  };

  const deleteMessage = (id: string) => {
      if(confirm("Delete this message?")) {
          DB.deleteChatMessage(id);
          setMessages(messages.filter(m => m.id !== id));
      }
  };

  const toggleLiveMode = async () => {
      if (isLive) {
          liveSession.current?.disconnect();
          liveSession.current = null;
          setIsLive(false);
      } else {
          setIsLive(true);
          try {
              liveSession.current = new LiveSession();
              liveSession.current.onStatusChange = (s) => setLiveStatus(s);
              await liveSession.current.connect();
          } catch (e) {
              setLiveStatus("Error Connecting");
              setTimeout(() => setIsLive(false), 2000);
          }
      }
  };

  // Render text with markdown images
  const renderContent = (text: string) => {
      const imgRegex = /!\[.*?\]\((data:image\/.*?;base64,.*?)\)/;
      const match = text.match(imgRegex);
      
      if (match) {
          const imgData = match[1];
          const textPart = text.replace(match[0], '').trim();
          return (
              <div className="flex flex-col gap-2">
                  <img src={imgData} alt="Generated" className="rounded-lg shadow-lg max-w-full border border-white/10" />
                  {textPart && <p className="whitespace-pre-wrap">{textPart}</p>}
              </div>
          );
      }
      return <p className="whitespace-pre-wrap leading-relaxed font-light">{text}</p>;
  };

  return (
    <div className="flex flex-col h-[calc(100vh-100px)] glass-panel rounded-2xl overflow-hidden shadow-2xl animate-fade-in relative">
        
        {/* Live Overlay */}
        {isLive && (
            <div className="absolute inset-0 z-50 bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center animate-fade-in">
                <button onClick={toggleLiveMode} className="absolute top-6 right-6 text-slate-500 hover:text-white">
                    <X size={32}/>
                </button>
                <div className="relative mb-12">
                    <div className="w-64 h-64 rounded-full bg-gradient-to-tr from-primary/30 to-secondary/30 blur-[60px] animate-pulse-slow absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
                    <div className="w-32 h-32 rounded-full border-2 border-primary/50 flex items-center justify-center relative z-10 bg-black/50 backdrop-blur-md shadow-[0_0_30px_rgba(139,92,246,0.3)] animate-float">
                        <Mic size={40} className="text-white animate-pulse"/>
                    </div>
                </div>
                <h2 className="text-3xl font-bold text-white mb-2 font-sans tracking-wide">Live Voice Link</h2>
                <p className={`font-mono text-sm uppercase tracking-widest ${liveStatus.includes('Error') ? 'text-red-400' : 'text-emerald-400'}`}>
                    {liveStatus}
                </p>
                <div className="mt-12 flex gap-4">
                   {[0, 100, 200, 300, 400].map(delay => <div key={delay} className="h-8 w-1 bg-secondary/50 rounded-full animate-pulse" style={{animationDelay: `${delay}ms`}}></div>)}
                </div>
            </div>
        )}

        {/* Header Controls */}
        <div className="absolute top-4 right-4 z-20 flex items-center gap-3">
            <button onClick={toggleLiveMode} className="p-2 rounded-full bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20 transition-all flex items-center gap-2 px-4 shadow-[0_0_15px_rgba(239,68,68,0.2)]">
                <Mic size={16}/> Live
            </button>
            <div className="flex bg-black/40 backdrop-blur-md rounded-xl p-1 border border-white/5">
                <button onClick={() => {setMode('lite'); setGrounding(false); setImgGenMode(false);}} className={`p-2 rounded-lg transition-all ${mode === 'lite' && !grounding && !imgGenMode ? 'bg-secondary text-black shadow-[0_0_10px_#06b6d4]' : 'text-slate-400 hover:text-white'}`} title="Flash Lite (Fast)"><Zap size={16} fill="currentColor"/></button>
                <button onClick={() => {setMode('standard'); setGrounding(false); setImgGenMode(false);}} className={`p-2 rounded-lg transition-all ${mode === 'standard' && !grounding && !imgGenMode ? 'bg-primary text-white shadow-[0_0_10px_#8b5cf6]' : 'text-slate-400 hover:text-white'}`} title="Flash 2.5 (Standard)"><Sparkles size={16}/></button>
                <button onClick={() => {setMode('thinking'); setGrounding(false); setImgGenMode(false);}} className={`p-2 rounded-lg transition-all ${mode === 'thinking' ? 'bg-pink-500 text-white shadow-[0_0_10px_#ec4899]' : 'text-slate-400 hover:text-white'}`} title="Pro 3 (Thinking)"><Brain size={16}/></button>
            </div>
            <Link to="/history" className="p-2 text-slate-500 hover:text-white bg-black/20 rounded-full hover:bg-black/50 transition-all border border-transparent hover:border-white/20" title="Archives"><HistoryIcon size={16}/></Link>
            <button onClick={clear} className="p-2 text-slate-500 hover:text-red-400 bg-black/20 rounded-full hover:bg-black/50 transition-all border border-transparent hover:border-red-500/30" title="Clear Chat"><Trash2 size={16}/></button>
        </div>

      <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar pt-16">
        {messages.map(msg => (
          <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''} animate-fade-in group`}>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border border-white/10 ${msg.role === 'user' ? 'bg-primary/20 text-primary' : 'bg-secondary/20 text-secondary'}`}>
              {msg.role === 'user' ? <UserIcon size={20} /> : <Bot size={20} />}
            </div>
            <div className={`max-w-[75%] p-5 rounded-2xl backdrop-blur-sm border relative ${msg.role === 'user' ? 'bg-primary/10 border-primary/20 text-indigo-50 rounded-tr-none' : 'bg-slate-800/40 border-white/5 text-slate-200 rounded-tl-none'}`}>
              {renderContent(msg.content)}
              {msg.role === 'model' && (
                  <button onClick={() => speakMessage(msg.content, msg.id)} className={`absolute -bottom-3 -left-2 w-8 h-8 rounded-full flex items-center justify-center bg-slate-900 border border-white/10 transition-all ${playingAudio === msg.id ? 'text-secondary animate-pulse border-secondary' : 'text-slate-500 hover:text-white hover:border-white/30'}`}>
                      {playingAudio === msg.id ? <Loader size={14} className="animate-spin"/> : <Volume2 size={14}/>}
                  </button>
              )}
              {/* Individual Message Delete */}
              <button 
                onClick={() => deleteMessage(msg.id)} 
                className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-slate-900 border border-white/10 flex items-center justify-center text-slate-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all z-10"
                title="Delete Message"
              >
                  <Trash2 size={12}/>
              </button>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-4">
             <div className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center border border-white/10"><Bot size={20} className="text-secondary animate-pulse" /></div>
             <div className="bg-slate-800/40 border border-white/5 p-4 rounded-2xl rounded-tl-none text-secondary/70 flex items-center gap-2">
                 {mode === 'thinking' ? <Brain size={16} className="animate-pulse"/> : <Sparkles size={16} className="animate-spin-slow"/>} 
                 {imgGenMode ? 'Synthesizing visual data...' : grounding ? 'Scanning knowledge grid...' : mode === 'thinking' ? 'Deep thinking...' : 'Computing...'}
             </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Advanced Toolbar */}
      <div className="bg-black/60 border-t border-white/5 p-2 px-6 flex items-center gap-4 backdrop-blur-md">
           {/* Image Gen Toggle */}
           <div className={`flex items-center gap-2 p-1 rounded-lg border ${imgGenMode ? 'bg-purple-500/20 border-purple-500/50' : 'border-transparent'}`}>
               <button onClick={() => {setImgGenMode(!imgGenMode); setGrounding(false); setAttachment(null);}} className={`p-2 rounded-lg transition-all ${imgGenMode ? 'text-purple-400' : 'text-slate-500 hover:text-white'}`} title="Generate Image"><ImageIcon size={18}/></button>
               {imgGenMode && (
                   <div className="flex text-xs font-mono">
                       {(['1K', '2K', '4K'] as ImageSize[]).map(s => (
                           <button key={s} onClick={() => setImgSize(s)} className={`px-2 py-1 rounded ${imgSize === s ? 'bg-purple-500 text-white' : 'text-slate-400 hover:text-white'}`}>{s}</button>
                       ))}
                   </div>
               )}
           </div>

           {/* Search Toggle */}
           <button onClick={() => {setGrounding(!grounding); setImgGenMode(false); setAttachment(null);}} className={`p-2 rounded-lg transition-all border ${grounding ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400' : 'border-transparent text-slate-500 hover:text-white'}`} title="Search Grounding"><Globe size={18}/></button>
           
           {/* Upload */}
           <label className="p-2 text-slate-500 hover:text-white cursor-pointer relative">
               <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload}/>
               <Paperclip size={18} className={attachment ? 'text-secondary' : ''}/>
               {attachment && <span className="absolute top-1 right-1 w-2 h-2 bg-secondary rounded-full"></span>}
           </label>

           {/* Audio Transcribe */}
           <button onClick={isRecording ? stopRecording : startRecording} className={`p-2 rounded-lg transition-all ${isRecording ? 'text-red-400 animate-pulse' : 'text-slate-500 hover:text-white'}`} title="Transcribe Audio">
               {isRecording ? <StopCircle size={18}/> : <Mic size={18}/>}
           </button>
      </div>

      <div className="p-6 bg-black/40 flex gap-4 backdrop-blur-md pt-2">
        <input 
          className="flex-1 holo-input rounded-xl px-6 py-4 focus:outline-none focus:ring-0"
          placeholder={imgGenMode ? `Describe ${imgSize} image to generate...` : grounding ? "Ask Google Search..." : attachment ? "Ask about this image..." : "Transmit query..."}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && sendMessage()}
        />
        <button 
            onClick={sendMessage} 
            disabled={loading} 
            className={`p-4 text-white rounded-xl disabled:opacity-50 transition-all shadow-lg hover:scale-105 ${
                imgGenMode ? 'bg-purple-600' : grounding ? 'bg-emerald-600' : mode === 'thinking' ? 'bg-pink-500' : 'bg-primary'
            }`}
        >
          {imgGenMode ? <ImageIcon size={24}/> : grounding ? <Globe size={24}/> : mode === 'thinking' ? <Brain size={24}/> : <Send size={24} />}
        </button>
      </div>
    </div>
  );
}