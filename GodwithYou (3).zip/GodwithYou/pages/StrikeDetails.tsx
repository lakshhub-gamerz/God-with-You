import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import * as DB from '../services/db';
import { generateStrikeGuidance } from '../services/ai';
import { Strike, StrikeParticipation } from '../types';
import { Flame, CheckCircle, Target, BrainCircuit, HeartPulse, ChevronLeft, Calendar, Shield, Cpu, Loader } from 'lucide-react';

export default function StrikeDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [strike, setStrike] = useState<Strike | null>(null);
  const [participation, setParticipation] = useState<StrikeParticipation | null>(null);
  const [loadingAI, setLoadingAI] = useState<string | null>(null);
  
  // AI State
  const [astraSteps, setAstraSteps] = useState<string[]>([]);
  const [lumaMessage, setLumaMessage] = useState<string>('');

  useEffect(() => {
    if(!id) return;
    const s = DB.getStrikeById(id);
    const p = DB.getMyStrikes().find(mp => mp.strikeId === id);
    
    if(s) setStrike(s);
    if(p) setParticipation(p);
  }, [id]);

  const toggleToday = () => {
      if(!participation) return;
      const today = new Date().toISOString().split('T')[0];
      const completed = participation.completedDates.includes(today);
      
      let newDates = [];
      if(completed) {
          newDates = participation.completedDates.filter(d => d !== today);
      } else {
          newDates = [...participation.completedDates, today];
          // Also check logic for day increments if we want, but keeping it simple based on completed dates
      }
      
      const updated = { ...participation, completedDates: newDates };
      setParticipation(updated);
      DB.updateStrikeParticipation(updated);
  };

  const engageAstra = async () => {
      if(!strike) return;
      setLoadingAI('ASTRA');
      const res = await generateStrikeGuidance('ASTRA', { difficulty: strike.difficulty, title: strike.title, dailyGoal: strike.dailyGoal });
      if(res.type === 'ASTRA' && Array.isArray(res.content)) {
          setAstraSteps(res.content);
      }
      setLoadingAI(null);
  };

  const engageLuma = async () => {
      if(!strike || !participation) return;
      setLoadingAI('LUMA');
      const res = await generateStrikeGuidance('LUMA', { 
          currentDay: participation.completedDates.length + 1, 
          durationDays: strike.durationDays, 
          title: strike.title, 
          difficulty: strike.difficulty 
      });
      if(res.type === 'LUMA' && typeof res.content === 'string') {
          setLumaMessage(res.content);
      }
      setLoadingAI(null);
  };

  if(!strike || !participation) return <div className="text-center py-20 text-slate-500">Protocol Not Found.</div>;

  const progress = Math.min(100, Math.round((participation.completedDates.length / strike.durationDays) * 100));
  const today = new Date().toISOString().split('T')[0];
  const isCompletedToday = participation.completedDates.includes(today);

  return (
    <div className="max-w-5xl mx-auto animate-fade-in pb-20">
        <button onClick={() => navigate('/strikes')} className="text-slate-500 hover:text-white flex items-center gap-2 mb-8 transition-colors">
            <ChevronLeft size={16}/> Back to Protocols
        </button>

        {/* Hero Section */}
        <div className="relative glass-panel rounded-3xl p-10 overflow-hidden mb-8 border border-orange-500/20">
            <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/10 rounded-full blur-[100px] pointer-events-none"></div>
            
            <div className="relative z-10 flex flex-col md:flex-row justify-between gap-8">
                <div>
                    <div className="flex items-center gap-3 mb-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border ${
                            strike.difficulty === 'god-mode' ? 'bg-red-500/10 border-red-500/50 text-red-400' : 'bg-emerald-500/10 border-emerald-500/50 text-emerald-400'
                        }`}>
                            {strike.difficulty} Protocol
                        </span>
                        <span className="text-slate-500 text-xs font-mono flex items-center gap-1">
                             <Target size={12}/> {strike.durationDays} Days
                        </span>
                    </div>
                    <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 font-sans tracking-tight">{strike.title}</h1>
                    <p className="text-xl text-slate-300 font-light flex items-center gap-2">
                        <Shield className="text-primary" size={20}/> Daily Directive: <span className="text-white font-bold">{strike.dailyGoal}</span>
                    </p>
                </div>

                <div className="flex flex-col items-center justify-center bg-black/20 p-6 rounded-2xl border border-white/5 backdrop-blur-sm min-w-[200px]">
                    <div className="text-4xl font-bold text-white mb-1 font-mono">{participation.completedDates.length}<span className="text-slate-500 text-lg">/{strike.durationDays}</span></div>
                    <div className="text-[10px] uppercase text-slate-500 font-bold tracking-widest mb-3">Days Completed</div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div className="bg-gradient-to-r from-orange-500 to-red-500 h-full transition-all duration-500" style={{width: `${progress}%`}}></div>
                    </div>
                </div>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Control Center */}
            <div className="lg:col-span-2 space-y-8">
                {/* Daily Check-in */}
                <div className="glass-panel p-8 rounded-2xl border border-white/10">
                    <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                        <Calendar className="text-secondary"/> Today's Log
                    </h3>
                    <div 
                        onClick={toggleToday}
                        className={`cursor-pointer p-6 rounded-xl border-2 transition-all flex items-center justify-between group ${
                            isCompletedToday 
                            ? 'bg-emerald-500/10 border-emerald-500/50 hover:bg-emerald-500/20' 
                            : 'bg-slate-800/50 border-slate-700 hover:border-white/30'
                        }`}
                    >
                        <div className="flex items-center gap-4">
                            <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${isCompletedToday ? 'bg-emerald-500 text-black' : 'bg-slate-700 text-slate-500'}`}>
                                <CheckCircle size={24} />
                            </div>
                            <div>
                                <h4 className={`text-lg font-bold ${isCompletedToday ? 'text-white' : 'text-slate-300'}`}>
                                    {isCompletedToday ? 'Objective Complete' : 'Mark as Complete'}
                                </h4>
                                <p className="text-slate-500 text-xs uppercase tracking-wider">{new Date().toLocaleDateString()}</p>
                            </div>
                        </div>
                        {isCompletedToday && <span className="text-emerald-400 font-bold text-sm uppercase tracking-widest animate-pulse">Synced</span>}
                    </div>
                </div>

                {/* Astra Tactical Support */}
                <div className="glass-panel p-8 rounded-2xl border border-secondary/20 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-secondary/10 rounded-full blur-[60px]"></div>
                    <div className="relative z-10">
                        <div className="flex justify-between items-start mb-6">
                            <div>
                                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                    <Cpu className="text-secondary"/> Astra Tactical
                                </h3>
                                <p className="text-slate-400 text-sm mt-1">Generate micro-steps for today's goal.</p>
                            </div>
                            <button 
                                onClick={engageAstra}
                                disabled={loadingAI === 'ASTRA'}
                                className="px-4 py-2 bg-secondary/10 hover:bg-secondary/20 text-secondary border border-secondary/30 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2"
                            >
                                {loadingAI === 'ASTRA' ? <Loader size={14} className="animate-spin"/> : <BrainCircuit size={14}/>} 
                                Optimize Protocol
                            </button>
                        </div>
                        
                        {astraSteps.length > 0 ? (
                            <div className="space-y-3 animate-slide-up">
                                {astraSteps.map((step, i) => (
                                    <div key={i} className="flex items-start gap-3 p-3 bg-black/20 rounded-lg border border-white/5">
                                        <span className="text-secondary font-mono text-xs mt-0.5">0{i+1}</span>
                                        <p className="text-slate-200 text-sm font-light">{step}</p>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="p-6 border border-dashed border-white/10 rounded-xl text-center text-slate-600 text-sm">
                                Awaiting tactical analysis...
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Luma Emotional Support */}
            <div>
                 <div className="glass-panel p-8 rounded-2xl border border-pink-500/20 h-full relative overflow-hidden flex flex-col">
                    <div className="absolute bottom-0 left-0 w-64 h-64 bg-pink-500/10 rounded-full blur-[80px]"></div>
                    <div className="relative z-10 flex-1 flex flex-col">
                        <div className="flex justify-between items-start mb-6">
                            <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                <HeartPulse className="text-pink-500"/> Luma Morale
                            </h3>
                        </div>

                        <div className="flex-1 flex flex-col justify-center items-center text-center p-6 bg-black/20 rounded-2xl border border-white/5 mb-6 min-h-[200px]">
                            {lumaMessage ? (
                                <p className="text-pink-200 text-lg font-light italic leading-relaxed animate-fade-in">"{lumaMessage}"</p>
                            ) : (
                                <p className="text-slate-600 text-sm">Neural Sync Idle...</p>
                            )}
                        </div>

                        <button 
                             onClick={engageLuma}
                             disabled={loadingAI === 'LUMA'}
                             className="w-full py-4 bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 text-pink-400 rounded-xl font-bold uppercase tracking-widest text-xs transition-all flex justify-center items-center gap-2"
                        >
                            {loadingAI === 'LUMA' ? <Loader size={14} className="animate-spin"/> : <Flame size={14}/>}
                            Sync Resonance
                        </button>
                    </div>
                 </div>
            </div>

        </div>
    </div>
  );
}