import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import * as DB from '../services/db';
import { Project } from '../types';
import { Plus, Folder, Hexagon, X, Trash2 } from 'lucide-react';

export default function Projects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');

  useEffect(() => {
    setProjects(DB.getProjects());
  }, []);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const newProj: Project = {
      id: crypto.randomUUID(),
      name: newName,
      description: newDesc || 'New Initiative',
      status: 'planning',
      progress: 0,
      tasks: []
    };
    DB.saveProject(newProj);
    setProjects([...projects, newProj]);
    
    // Reset and close
    setNewName('');
    setNewDesc('');
    setShowModal(false);
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
      e.preventDefault();
      e.stopPropagation();
      if(confirm('Delete Mission Protocol?')) {
          DB.deleteProject(id);
          setProjects(projects.filter(p => p.id !== id));
      }
  };

  return (
    <div className="relative animate-fade-in">
      <div className="flex justify-between items-center mb-10">
        <div>
            <h1 className="text-4xl font-bold text-white mb-2">Missions</h1>
            <p className="text-slate-400 font-mono text-sm">Active Directives & Long-term Goals</p>
        </div>
        <button 
          onClick={() => setShowModal(true)} 
          className="neon-button px-6 py-3 text-white rounded-xl flex items-center gap-2 font-bold uppercase tracking-wider text-sm hover:scale-105 transition-transform"
        >
          <Plus size={18} /> Initialize Project
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map(p => (
          <Link key={p.id} to={`/projects/${p.id}`} className="block group">
            <div className="glass-card p-8 rounded-3xl h-full flex flex-col relative overflow-hidden transition-all duration-300 hover:border-primary/40">
              {/* Decorative background element */}
              <div className="absolute -right-6 -top-6 text-white/5 transform rotate-12 group-hover:rotate-0 transition-transform duration-500">
                  <Hexagon size={120} strokeWidth={1}/>
              </div>

              <div className="flex justify-between items-start mb-6 relative z-10">
                <div className="p-4 bg-slate-800/80 rounded-2xl text-primary border border-white/10 group-hover:border-primary/50 transition-colors">
                  <Folder size={24}/>
                </div>
                <div className="flex items-center gap-2">
                    <span className={`text-[10px] px-3 py-1 rounded-full uppercase tracking-widest font-bold border ${p.status === 'active' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-slate-700/30 border-slate-600 text-slate-400'}`}>
                    {p.status}
                    </span>
                    <button onClick={(e) => handleDelete(e, p.id)} className="p-1 text-slate-600 hover:text-red-400 transition-colors z-20"><Trash2 size={16}/></button>
                </div>
              </div>
              <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-primary transition-colors">{p.name}</h3>
              <p className="text-slate-400 text-sm mb-6 truncate font-light">{p.description}</p>
              
              <div className="mt-auto">
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mb-2">
                    <div className="bg-gradient-to-r from-primary to-secondary h-full transition-all duration-1000" style={{ width: `${p.progress}%` }}></div>
                </div>
                <div className="text-right text-xs text-slate-500 font-mono">{p.progress}% Complete</div>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Creation Modal */}
      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
           <div className="glass-panel p-8 rounded-3xl w-full max-w-md shadow-[0_0_50px_rgba(0,0,0,0.5)] relative border border-white/10">
              <button 
                onClick={() => setShowModal(false)} 
                className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors"
              >
                <X size={24} />
              </button>
              
              <div className="mb-6">
                <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center text-primary mb-4 border border-primary/30">
                   <Plus size={24} />
                </div>
                <h2 className="text-2xl font-bold text-white">Initialize New Mission</h2>
                <p className="text-slate-400 text-sm">Define the parameters of your new undertaking.</p>
              </div>

              <form onSubmit={handleCreate} className="space-y-5">
                  <div>
                    <label className="block text-xs font-bold text-primary mb-2 uppercase tracking-wider">Mission Codename</label>
                    <input 
                        autoFocus
                        className="w-full holo-input px-4 py-3 rounded-xl focus:outline-none focus:ring-1 focus:ring-primary/50 text-white"
                        value={newName}
                        onChange={e => setNewName(e.target.value)}
                        placeholder="e.g. Project Genesis"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 mb-2 uppercase tracking-wider">Directive Description</label>
                    <textarea 
                        className="w-full holo-input px-4 py-3 rounded-xl focus:outline-none resize-none h-28 text-white"
                        value={newDesc}
                        onChange={e => setNewDesc(e.target.value)}
                        placeholder="Briefing details and primary objectives..."
                    />
                  </div>
                  <div className="flex gap-3 pt-2">
                      <button 
                        type="button" 
                        onClick={() => setShowModal(false)} 
                        className="flex-1 px-4 py-3 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-colors font-bold text-sm uppercase tracking-wide"
                      >
                        Abort
                      </button>
                      <button 
                        type="submit" 
                        className="flex-1 neon-button px-6 py-3 text-white rounded-xl font-bold text-sm uppercase tracking-wide shadow-lg hover:shadow-primary/20 transition-all"
                      >
                        Launch Mission
                      </button>
                  </div>
              </form>
           </div>
        </div>
      )}
    </div>
  );
}