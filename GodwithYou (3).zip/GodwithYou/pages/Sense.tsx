import React, { useState } from 'react';
import * as DB from '../services/db';
import { generateJSON } from '../services/ai';
import { Sparkles, Sun, Battery, Coffee, Zap, Gauge, Clock, Cloud } from 'lucide-react';

export default function Sense() {
  const [energy, setEnergy] = useState(50);
  const [mood, setMood] = useState(50);
  const [context, setContext] = useState('');
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const generatePlan = async () => {
    setLoading(true);
    // Fetch active projects to context
    const projects = DB.getProjects().filter(p => p.status === 'active').map(p => p.name).join(', ');
    const timeOfDay = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    const prompt = `
      User State: Energy: ${energy}/100, Mood: ${mood}/100, Context: ${context}.
      Time of Day: ${timeOfDay}.
      Active Projects: ${projects}.
      
      Generate 3 specific, actionable tasks tailored exactly to this biometric state and time.
      Avoid generic advice. Be specific.
      Return JSON: { "tasks": [{ "title": "Task Name", "duration": "30m", "rationale": "Why this fits now" }] }
    `;
    const data = await generateJSON(prompt);
    setRecommendations(data.tasks || []);
    setLoading(false);
  };

  return (
    <div className="max-w-3xl mx-auto animate-fade-in pb-20">
      <div className="text-center mb-12">
        <div className="inline-block p-5 rounded-full bg-gradient-to-br from-secondary/20 to-primary/20 border border-white/10 mb-6 shadow-[0_0_30px_rgba(6,182,212,0.2)]">
            <Gauge className="w-12 h-12 text-secondary" />
        </div>
        <h1 className="text-5xl font-bold text-white mb-3 tracking-tight font-sans">Sense Mode</h1>
        <p className="text-slate-400 font-light text-lg">Biometric State Alignment & Temporal Context</p>
      </div>

      <div className="glass-panel p-10 rounded-3xl space-y-10 relative overflow-hidden">
        {/* Background blobs */}
        <div className="absolute -left-20 top-20 w-64 h-64 bg-primary/5 rounded-full blur-[80px]"></div>
        <div className="absolute -right-20 bottom-20 w-64 h-64 bg-secondary/5 rounded-full blur-[80px]"></div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="relative z-10">
                <div className="flex justify-between mb-4">
                    <label className="text-sm font-bold text-white flex items-center gap-2 uppercase tracking-wider"><Battery size={16} className="text-primary"/> Vitality</label>
                    <span className="text-primary font-mono text-xl">{energy}%</span>
                </div>
                <input type="range" min="0" max="100" value={energy} onChange={e => setEnergy(parseInt(e.target.value))} className="w-full accent-primary h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer" />
            </div>

            <div className="relative z-10">
                <div className="flex justify-between mb-4">
                    <label className="text-sm font-bold text-white flex items-center gap-2 uppercase tracking-wider"><Sun size={16} className="text-secondary"/> Valence</label>
                    <span className="text-secondary font-mono text-xl">{mood}%</span>
                </div>
                <input type="range" min="0" max="100" value={mood} onChange={e => setMood(parseInt(e.target.value))} className="w-full accent-secondary h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer" />
            </div>
        </div>

        <div className="relative z-10">
          <label className="block text-sm font-bold text-slate-300 mb-4 uppercase tracking-wider flex items-center gap-2">
              <Cloud size={16}/> Environmental Context
          </label>
          <input 
            className="w-full holo-input p-5 rounded-2xl focus:outline-none text-lg font-light"
            placeholder="Input current constraints (e.g., 'Only 20 mins free, feeling distracted')"
            value={context}
            onChange={e => setContext(e.target.value)}
          />
        </div>

        <button 
          onClick={generatePlan}
          disabled={loading}
          className="w-full py-5 bg-white text-darker font-bold rounded-2xl hover:bg-slate-200 transition-all hover:scale-[1.01] flex justify-center items-center gap-3 shadow-[0_0_30px_rgba(255,255,255,0.15)] uppercase tracking-widest text-sm relative z-10"
        >
          {loading ? <Sparkles className="animate-spin"/> : <Sparkles />}
          {loading ? 'Aligning Biometrics...' : 'Generate Adaptive Protocol'}
        </button>
      </div>

      <div className="mt-10 space-y-6">
        {recommendations.map((task, i) => (
          <div key={i} className="animate-slide-up glass-card p-8 rounded-2xl border-l-4 border-l-secondary flex items-start gap-6 hover:translate-x-2 transition-transform">
            <div className="p-4 bg-slate-800/50 rounded-full border border-white/10 shrink-0">
              {energy > 70 ? <Zap size={24} className="text-yellow-400" /> : <Coffee size={24} className="text-orange-400" />}
            </div>
            <div>
              <div className="flex flex-col md:flex-row md:items-center gap-3 mb-2">
                <h3 className="font-bold text-white text-xl font-sans">{task.title}</h3>
                <span className="text-xs bg-white/5 border border-white/10 px-3 py-1 rounded-full text-slate-300 font-mono flex items-center gap-1 w-fit">
                    <Clock size={12}/> {task.duration}
                </span>
              </div>
              <p className="text-slate-400 leading-relaxed font-light">{task.rationale}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
