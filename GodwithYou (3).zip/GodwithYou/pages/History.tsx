import React, { useState, useEffect } from 'react';
import * as DB from '../services/db';
import { Activity, Clock, BrainCircuit, HeartPulse, GitFork, ListFilter, Trash2 } from 'lucide-react';

export default function HistoryPage() {
  const [items, setItems] = useState<any[]>([]);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    // Aggregate all data types for a feed
    const decisions = DB.getDecisions().map(d => ({ ...d, type: 'decision' }));
    const emotions = DB.getEmotions().map(e => ({ ...e, type: 'emotion' }));
    const timeline = DB.getTimeline().map(t => ({ ...t, type: 'timeline', timestamp: new Date(t.date).getTime() }));
    
    const all = [...decisions, ...emotions, ...timeline].sort((a: any, b: any) => b.timestamp - a.timestamp);
    setItems(all);
  }, []);

  const handleDelete = (id: string, type: string) => {
      if(!confirm("Purge record from timeline?")) return;
      if(type === 'decision') DB.deleteDecision(id);
      if(type === 'emotion') DB.deleteEmotion(id);
      if(type === 'timeline') DB.deleteTimelineEvent(id);
      setItems(items.filter(i => i.id !== id));
  };

  const filtered = filter === 'all' ? items : items.filter(i => i.type === filter);

  return (
    <div className="animate-fade-in max-w-4xl mx-auto pb-20">
      <div className="flex flex-col md:flex-row justify-between items-end md:items-center mb-10 gap-4">
        <div>
           <h1 className="text-4xl font-bold text-white mb-2">Chronicles</h1>
           <p className="text-slate-400 font-mono text-sm">System Logs & Event History</p>
        </div>
        
        <div className="relative">
            <ListFilter className="absolute left-3 top-3 text-slate-400" size={16}/>
            <select 
                className="pl-10 pr-4 py-2 bg-white/5 border border-white/10 text-white rounded-lg focus:outline-none focus:border-primary appearance-none cursor-pointer hover:bg-white/10 transition-colors"
                value={filter}
                onChange={e => setFilter(e.target.value)}
            >
                <option value="all">All Events</option>
                <option value="decision">Quantum Decisions</option>
                <option value="emotion">Emotional Logs</option>
                <option value="timeline">Timeline Shifts</option>
            </select>
        </div>
      </div>

      <div className="space-y-4">
        {filtered.length === 0 && <div className="text-center text-slate-500 py-20 italic">No historical data found in this sector.</div>}
        
        {filtered.map((item, idx) => (
            <div key={idx} className="glass-card p-6 rounded-2xl border border-white/5 flex gap-5 hover:translate-x-1 transition-transform group relative">
                <button 
                    onClick={() => handleDelete(item.id, item.type)}
                    className="absolute top-6 right-6 text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                    <Trash2 size={16}/>
                </button>
                <div className={`w-12 h-12 rounded-full shrink-0 flex items-center justify-center border border-white/10
                    ${item.type === 'decision' ? 'bg-purple-500/10 text-purple-400' : 
                      item.type === 'emotion' ? 'bg-pink-500/10 text-pink-400' : 'bg-blue-500/10 text-blue-400'}`} 
                >
                    {item.type === 'decision' && <BrainCircuit size={20}/>}
                    {item.type === 'emotion' && <HeartPulse size={20}/>}
                    {item.type === 'timeline' && <GitFork size={20}/>}
                </div>
                
                <div className="flex-1">
                    <div className="flex justify-between items-start mb-1">
                        <div className="flex gap-3 items-center">
                            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
                                item.type === 'decision' ? 'border-purple-500/30 text-purple-400' : 
                                item.type === 'emotion' ? 'border-pink-500/30 text-pink-400' : 'border-blue-500/30 text-blue-400'
                            }`}>{item.type}</span>
                        </div>
                        <span className="text-xs text-slate-500 font-mono flex items-center gap-1 pr-8">
                             <Clock size={12}/>
                             {item.timestamp ? new Date(item.timestamp).toLocaleDateString() : item.date}
                        </span>
                    </div>

                    {item.type === 'decision' && (
                        <div className="mt-2">
                            <h3 className="font-bold text-white text-lg">{item.query}</h3>
                            <p className="text-slate-400 text-sm mt-1 border-l-2 border-purple-500/30 pl-3">Recommended: <span className="text-slate-200">{item.recommendation || 'Analysis Pending'}</span></p>
                        </div>
                    )}
                    {item.type === 'emotion' && (
                        <div className="mt-2">
                            <h3 className="font-bold text-white flex items-center gap-2">Valence Level: <span className="text-pink-400">{item.mood}/10</span></h3>
                            {item.note && <p className="text-slate-400 text-sm mt-1 italic">"{item.note}"</p>}
                        </div>
                    )}
                    {item.type === 'timeline' && (
                        <div className="mt-2">
                             <h3 className="font-bold text-white text-lg">{item.title}</h3>
                             <p className="text-slate-400 text-sm mt-1 font-light">{item.description}</p>
                        </div>
                    )}
                </div>
            </div>
        ))}
      </div>
    </div>
  );
}