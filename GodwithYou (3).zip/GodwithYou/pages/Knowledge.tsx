import React, { useState } from 'react';
import * as DB from '../services/db';
import { generateJSON } from '../services/ai';
import { KnowledgeItem } from '../types';
import { Search, BookOpen, Share, Download, Cpu, Layers, Play } from 'lucide-react';

export default function Knowledge() {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<KnowledgeItem | null>(null);

  const search = async () => {
    if (!query) return;
    setLoading(true);
    
    // Astra Prompt
    const prompt = `
        Act as ASTRA (Knowledge Engine).
        Query: "${query}"
        
        Generate a structured response.
        If the query is actionable, generate a step-by-step workflow (TimeWarp).
        If the query is informational, provide a deep summary.
        
        Return JSON: { 
            "summary": "High-level abstract.", 
            "explanation": "Detailed breakdown.", 
            "workflow": ["Step 1: ...", "Step 2: ...", "Step 3: ..."],
            "sources": ["Concept A", "Method B"] 
        }
    `;
    const data = await generateJSON(prompt);
    
    const item: KnowledgeItem = {
      id: crypto.randomUUID(),
      query,
      summary: data.summary || "Analysis incomplete.",
      explanation: data.explanation || "No deep data available.",
      workflow: data.workflow || [],
      sources: data.sources || [],
      timestamp: Date.now()
    };
    
    DB.addKnowledge(item);
    setResult(item);
    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto animate-fade-in pb-20">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-white mb-6 tracking-tight font-sans">QueryNet (Astra)</h1>
        <div className="relative group max-w-2xl mx-auto">
          <div className="absolute inset-0 bg-gradient-to-r from-secondary via-primary to-secondary opacity-20 blur-2xl rounded-full group-hover:opacity-40 transition-opacity"></div>
          <input 
            className="w-full bg-black/60 backdrop-blur-xl border border-white/20 rounded-full py-5 pl-14 pr-6 text-white text-lg focus:border-secondary focus:outline-none shadow-2xl relative z-10 font-light"
            placeholder="Input goal, question, or skill to master..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && search()}
          />
          <Search className="absolute left-6 top-6 text-slate-400 z-20 group-hover:text-secondary transition-colors" size={20} />
        </div>
      </div>

      {loading && (
        <div className="text-center text-secondary animate-pulse font-mono text-sm uppercase tracking-widest flex justify-center items-center gap-3">
          <Cpu className="animate-spin" />
          Astra Processing Matrix...
        </div>
      )}

      {result && (
        <div className="glass-panel p-10 rounded-3xl animate-fade-in relative overflow-hidden border-t border-secondary/20">
          <div className="absolute top-0 right-0 p-10 opacity-5 text-secondary">
              <Layers size={300} />
          </div>

          <div className="flex justify-between items-start mb-10 border-b border-white/10 pb-6 relative z-10">
             <div>
                 <span className="text-xs font-bold text-secondary uppercase tracking-widest mb-2 block">Query Analysis</span>
                 <h2 className="text-3xl font-bold text-white capitalize font-sans">{result.query}</h2>
             </div>
             <button className="text-slate-500 hover:text-white transition-colors p-2 bg-white/5 rounded-lg"><Download size={20}/></button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 relative z-10">
            {/* Info Column */}
            <div className="space-y-8">
                <div>
                    <h3 className="text-xs font-bold text-slate-400 uppercase mb-3 tracking-[0.2em]">Summary</h3>
                    <p className="text-lg text-slate-200 leading-relaxed font-light">{result.summary}</p>
                </div>
                <div className="bg-black/30 border border-white/5 p-6 rounded-2xl">
                    <h3 className="text-xs font-bold text-slate-400 uppercase mb-3 tracking-[0.2em]">Deep Dive</h3>
                    <p className="text-slate-400 leading-relaxed text-sm font-light">{result.explanation}</p>
                </div>
            </div>

            {/* Workflow / TimeWarp Column */}
            <div>
                 <h3 className="text-xs font-bold text-secondary uppercase mb-4 tracking-[0.2em] flex items-center gap-2">
                     <Play size={14} fill="currentColor"/> TimeWarp Workflows
                 </h3>
                 <div className="space-y-3">
                     {result.workflow && result.workflow.length > 0 ? (
                         result.workflow.map((step, i) => (
                             <div key={i} className="flex items-center gap-4 p-4 glass-card rounded-xl hover:translate-x-1 cursor-pointer group">
                                 <div className="w-8 h-8 rounded-full bg-secondary/10 border border-secondary/30 flex items-center justify-center text-secondary font-mono text-xs shrink-0 group-hover:bg-secondary group-hover:text-black transition-colors">
                                     {i + 1}
                                 </div>
                                 <span className="text-slate-300 font-light text-sm">{step}</span>
                             </div>
                         ))
                     ) : (
                         <div className="text-slate-500 italic text-sm">No workflow generated. Pure information response.</div>
                     )}
                 </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}