import React, { useState, useEffect } from 'react';
import * as DB from '../services/db';
import * as AI from '../services/ai';
import { Note } from '../types';
import { Plus, Search, Tag, Trash, Wand2, FileText, Copy, AlignLeft, Trash2 } from 'lucide-react';
import { generateContent, generateJSON } from '../services/ai';

export default function Workspace() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [search, setSearch] = useState('');
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    setNotes(DB.getNotes());
  }, []);

  const createNote = () => {
    const newNote: Note = {
      id: crypto.randomUUID(),
      title: 'New Neural Node',
      content: '',
      tags: [],
      priority: 'medium',
      updatedAt: Date.now()
    };
    DB.saveNote(newNote);
    setNotes([newNote, ...notes]);
    setSelectedNote(newNote);
  };

  const saveCurrent = (n: Note) => {
    DB.saveNote(n);
    setNotes(notes.map(note => note.id === n.id ? n : note));
    setSelectedNote(n);
  };

  const deleteSelected = () => {
    if (!selectedNote) return;
    DB.deleteNote(selectedNote.id);
    setNotes(notes.filter(n => n.id !== selectedNote.id));
    setSelectedNote(null);
  };

  const handleDeleteNote = (e: React.MouseEvent, id: string) => {
      e.stopPropagation();
      if(confirm("Delete this memory node permanently?")) {
          DB.deleteNote(id);
          setNotes(notes.filter(n => n.id !== id));
          if (selectedNote?.id === id) setSelectedNote(null);
      }
  };

  const autoOrganize = async () => {
    if (!selectedNote || !selectedNote.content) return;
    setProcessing(true);
    const prompt = `Analyze this note and provide 3 short tags and a better title. Format: Title|tag1,tag2,tag3. Content: ${selectedNote.content}`;
    const res = await generateContent(prompt);
    
    if (res.includes('|')) {
        const parts = res.split('|');
        if (parts.length >= 2) {
            const newTitle = parts[0].trim();
            const tagsStr = parts[1];
            // Safe filtering of empty tags
            const tags = tagsStr.split(',').map(t => t.trim()).filter(t => t.length > 0);
            const updated = { ...selectedNote, title: newTitle, tags };
            saveCurrent(updated);
        }
    }
    setProcessing(false);
  };

  const generateSummary = async () => {
      if (!selectedNote?.content) return;
      setProcessing(true);
      const summary = await generateContent(`Summarize this note in 2 bullet points:\n${selectedNote.content}`);
      const updated = { ...selectedNote, aiSummary: summary };
      saveCurrent(updated);
      setProcessing(false);
  };

  const findSimilar = async () => {
      setProcessing(true);
      const groups = await AI.findDuplicates(notes);
      const myGroup = groups.find(g => g.includes(selectedNote?.id));
      if (myGroup && myGroup.length > 1) {
          alert(`Potential duplicate/related notes found: ${myGroup.length - 1} other(s).`);
      } else {
          alert("No significant duplicates found.");
      }
      setProcessing(false);
  };

  const filteredNotes = notes.filter(n => n.title.toLowerCase().includes(search.toLowerCase()) || n.content.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex flex-col md:flex-row h-[calc(100vh-140px)] glass-panel rounded-2xl overflow-hidden shadow-2xl animate-fade-in">
      {/* Sidebar List */}
      <div className="w-full md:w-80 h-1/3 md:h-auto border-b md:border-b-0 md:border-r border-white/5 flex flex-col bg-black/20 backdrop-blur-md">
        <div className="p-4 border-b border-white/5">
          <div className="flex gap-2 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 text-slate-500" size={16} />
              <input 
                className="w-full bg-white/5 pl-9 pr-3 py-2 rounded-lg text-sm text-white focus:outline-none focus:bg-white/10 transition-colors border border-transparent focus:border-primary/30" 
                placeholder="Search matrix..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
            <button onClick={createNote} className="p-2 bg-primary/80 hover:bg-primary text-white rounded-lg shadow-[0_0_10px_rgba(139,92,246,0.5)] transition-all">
              <Plus size={20} />
            </button>
          </div>
          <h2 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Memory Banks</h2>
        </div>
        <div className="overflow-y-auto flex-1 custom-scrollbar p-2 space-y-1">
          {filteredNotes.map(note => (
            <div 
              key={note.id} 
              onClick={() => setSelectedNote(note)}
              className={`p-3 rounded-lg cursor-pointer transition-all border border-transparent group relative ${
                  selectedNote?.id === note.id 
                  ? 'bg-primary/10 border-primary/30 text-white shadow-[0_0_15px_rgba(139,92,246,0.1)]' 
                  : 'hover:bg-white/5 text-slate-400 hover:text-slate-200'
              }`}
            >
              <h3 className="font-bold text-sm truncate flex items-center gap-2 pr-6">
                 <FileText size={12} className={selectedNote?.id === note.id ? 'text-primary' : 'text-slate-600'} />
                 {note.title}
              </h3>
              <p className="text-xs opacity-60 mt-1 truncate pl-5">{note.content || "Empty node..."}</p>
              
              <button 
                  onClick={(e) => handleDeleteNote(e, note.id)} 
                  className="absolute right-2 top-2 p-1.5 text-slate-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all hover:bg-white/10 rounded-full"
                  title="Delete Note"
              >
                  <Trash2 size={12} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 flex flex-col bg-slate-900/30 relative h-2/3 md:h-auto">
        {selectedNote ? (
          <>
            <div className="p-6 border-b border-white/5 flex flex-col md:flex-row justify-between items-start md:items-center bg-white/5 backdrop-blur-sm gap-4">
              <input 
                className="text-2xl font-bold bg-transparent text-white focus:outline-none w-full font-sans tracking-wide placeholder-slate-600" 
                value={selectedNote.title}
                onChange={e => saveCurrent({...selectedNote, title: e.target.value})}
              />
              <div className="flex gap-2 self-end md:self-auto">
                <button onClick={generateSummary} disabled={processing} className="p-2 text-secondary hover:bg-secondary/10 rounded-lg transition-colors" title="Generate Summary">
                    <AlignLeft size={20} />
                </button>
                <button onClick={findSimilar} disabled={processing} className="p-2 text-amber-400 hover:bg-amber-400/10 rounded-lg transition-colors" title="Check Duplicates">
                    <Copy size={20} />
                </button>
                <button onClick={autoOrganize} disabled={processing} className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-colors" title="AI Auto-Tag">
                  <Wand2 size={20} className={processing ? 'animate-spin' : ''} />
                </button>
                <button onClick={deleteSelected} className="p-2 text-red-400 hover:bg-red-500/10 rounded-lg transition-colors">
                  <Trash size={20} />
                </button>
              </div>
            </div>
            
            <div className="flex-1 flex flex-col relative overflow-y-auto custom-scrollbar">
                <textarea 
                className="flex-1 bg-transparent p-8 text-slate-200 resize-none focus:outline-none leading-relaxed text-lg font-light selection:bg-primary/30 min-h-[300px]"
                placeholder="Input neural data..."
                value={selectedNote.content}
                onChange={e => saveCurrent({...selectedNote, content: e.target.value})}
                />
                
                {selectedNote.aiSummary && (
                    <div className="m-8 p-4 bg-primary/10 border border-primary/20 rounded-xl text-sm text-slate-300 shrink-0">
                        <h4 className="text-xs font-bold text-primary uppercase mb-1">Quick Summary</h4>
                        {selectedNote.aiSummary}
                    </div>
                )}
            </div>

            <div className="p-4 border-t border-white/5 flex gap-2 items-center px-8 bg-black/20 shrink-0">
                <Tag size={14} className="text-slate-500"/>
                {selectedNote.tags.length === 0 && <span className="text-xs text-slate-600 italic">No tags attached</span>}
                {selectedNote.tags.map(t => <span key={t} className="text-xs bg-slate-800 border border-slate-700 px-2 py-1 rounded text-primary">{t}</span>)}
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-600 gap-4">
             <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center animate-pulse">
                <FileText size={40} className="opacity-20"/>
             </div>
             <p className="font-light">Select a memory node to decode.</p>
          </div>
        )}
      </div>
    </div>
  );
}