import React, { Component, ReactNode } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

interface ErrorBoundaryProps {
  children?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

// Safety Error Boundary to catch runtime crashes
class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public state: ErrorBoundaryState = {
    hasError: false,
    error: null
  };

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("Critical System Failure:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          height: '100vh', 
          width: '100vw', 
          backgroundColor: '#000', 
          color: '#ef4444', 
          display: 'flex', 
          flexDirection: 'column', 
          alignItems: 'center', 
          justifyContent: 'center', 
          fontFamily: 'monospace',
          padding: '2rem',
          textAlign: 'center'
        }}>
          <h1 style={{fontSize: '2rem', marginBottom: '1rem', textTransform: 'uppercase', letterSpacing: '0.2em'}}>System Critical Error</h1>
          <div style={{border: '1px solid #333', padding: '1.5rem', borderRadius: '0.5rem', backgroundColor: '#111', maxWidth: '800px'}}>
            <p style={{marginBottom: '1rem', color: '#9ca3af'}}>The Neural Interface encountered an unrecoverable exception.</p>
            <pre style={{whiteSpace: 'pre-wrap', wordBreak: 'break-all', fontSize: '0.8rem'}}>
              {this.state.error?.message || 'Unknown Error'}
            </pre>
            <br/>
            <button 
              onClick={() => window.location.reload()}
              style={{
                background: '#333', 
                color: 'white', 
                border: 'none', 
                padding: '0.5rem 1rem', 
                cursor: 'pointer',
                marginTop: '1rem',
                borderRadius: '0.25rem'
              }}
            >
              Reboot System
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (!rootElement) throw new Error('Failed to find the root element');

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);